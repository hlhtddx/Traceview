/*    */ package com.android.traceview;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Selection
/*    */ {
/*    */   private Action mAction;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String mName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private Object mValue;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Selection(Action action, String name, Object value)
/*    */   {
/* 26 */     this.mAction = action;
/* 27 */     this.mName = name;
/* 28 */     this.mValue = value;
/*    */   }
/*    */   
/*    */   public static Selection highlight(String name, Object value) {
/* 32 */     return new Selection(Action.Highlight, name, value);
/*    */   }
/*    */   
/*    */   public static Selection include(String name, Object value) {
/* 36 */     return new Selection(Action.Include, name, value);
/*    */   }
/*    */   
/*    */   public static Selection exclude(String name, Object value) {
/* 40 */     return new Selection(Action.Exclude, name, value);
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 44 */     this.mName = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 48 */     return this.mName;
/*    */   }
/*    */   
/*    */   public void setValue(Object value) {
/* 52 */     this.mValue = value;
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 56 */     return this.mValue;
/*    */   }
/*    */   
/*    */   public void setAction(Action action) {
/* 60 */     this.mAction = action;
/*    */   }
/*    */   
/*    */   public Action getAction() {
/* 64 */     return this.mAction;
/*    */   }
/*    */   
/*    */   public static enum Action {
/* 68 */     Highlight,  Include,  Exclude,  Aggregate;
/*    */     
/*    */     private Action() {}
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/Selection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
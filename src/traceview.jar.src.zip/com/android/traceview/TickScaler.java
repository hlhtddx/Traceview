/*     */ package com.android.traceview;
/*     */ 
/*     */ 
/*     */ 
/*     */ class TickScaler
/*     */ {
/*     */   private double mMinVal;
/*     */   
/*     */ 
/*     */   private double mMaxVal;
/*     */   
/*     */ 
/*     */   private double mRangeVal;
/*     */   
/*     */ 
/*     */   private int mNumPixels;
/*     */   
/*     */ 
/*     */   private int mPixelsPerTick;
/*     */   
/*     */ 
/*     */   private double mPixelsPerRange;
/*     */   
/*     */   private double mTickIncrement;
/*     */   
/*     */   private double mMinMajorTick;
/*     */   
/*     */ 
/*     */   TickScaler(double minVal, double maxVal, int numPixels, int pixelsPerTick)
/*     */   {
/*  31 */     this.mMinVal = minVal;
/*  32 */     this.mMaxVal = maxVal;
/*  33 */     this.mNumPixels = numPixels;
/*  34 */     this.mPixelsPerTick = pixelsPerTick;
/*     */   }
/*     */   
/*     */   public void setMinVal(double minVal) {
/*  38 */     this.mMinVal = minVal;
/*     */   }
/*     */   
/*     */   public double getMinVal() {
/*  42 */     return this.mMinVal;
/*     */   }
/*     */   
/*     */   public void setMaxVal(double maxVal) {
/*  46 */     this.mMaxVal = maxVal;
/*     */   }
/*     */   
/*     */   public double getMaxVal() {
/*  50 */     return this.mMaxVal;
/*     */   }
/*     */   
/*     */   public void setNumPixels(int numPixels) {
/*  54 */     this.mNumPixels = numPixels;
/*     */   }
/*     */   
/*     */   public int getNumPixels() {
/*  58 */     return this.mNumPixels;
/*     */   }
/*     */   
/*     */   public void setPixelsPerTick(int pixelsPerTick) {
/*  62 */     this.mPixelsPerTick = pixelsPerTick;
/*     */   }
/*     */   
/*     */   public int getPixelsPerTick() {
/*  66 */     return this.mPixelsPerTick;
/*     */   }
/*     */   
/*     */   public void setPixelsPerRange(double pixelsPerRange) {
/*  70 */     this.mPixelsPerRange = pixelsPerRange;
/*     */   }
/*     */   
/*     */   public double getPixelsPerRange() {
/*  74 */     return this.mPixelsPerRange;
/*     */   }
/*     */   
/*     */   public void setTickIncrement(double tickIncrement) {
/*  78 */     this.mTickIncrement = tickIncrement;
/*     */   }
/*     */   
/*     */   public double getTickIncrement() {
/*  82 */     return this.mTickIncrement;
/*     */   }
/*     */   
/*     */   public void setMinMajorTick(double minMajorTick) {
/*  86 */     this.mMinMajorTick = minMajorTick;
/*     */   }
/*     */   
/*     */   public double getMinMajorTick() {
/*  90 */     return this.mMinMajorTick;
/*     */   }
/*     */   
/*     */   public int valueToPixel(double value)
/*     */   {
/*  95 */     return (int)Math.ceil(this.mPixelsPerRange * (value - this.mMinVal) - 0.5D);
/*     */   }
/*     */   
/*     */   public double valueToPixelFraction(double value)
/*     */   {
/* 100 */     return this.mPixelsPerRange * (value - this.mMinVal);
/*     */   }
/*     */   
/*     */   public double pixelToValue(int pixel)
/*     */   {
/* 105 */     return this.mMinVal + pixel / this.mPixelsPerRange;
/*     */   }
/*     */   
/*     */   public void computeTicks(boolean useGivenEndPoints) {
/* 109 */     int numTicks = this.mNumPixels / this.mPixelsPerTick;
/* 110 */     this.mRangeVal = (this.mMaxVal - this.mMinVal);
/* 111 */     this.mTickIncrement = (this.mRangeVal / numTicks);
/* 112 */     double dlogTickIncrement = Math.log10(this.mTickIncrement);
/* 113 */     int logTickIncrement = (int)Math.floor(dlogTickIncrement);
/* 114 */     double scale = Math.pow(10.0D, logTickIncrement);
/* 115 */     double scaledTickIncr = this.mTickIncrement / scale;
/* 116 */     if (scaledTickIncr > 5.0D) {
/* 117 */       scaledTickIncr = 10.0D;
/* 118 */     } else if (scaledTickIncr > 2.0D) {
/* 119 */       scaledTickIncr = 5.0D;
/* 120 */     } else if (scaledTickIncr > 1.0D) {
/* 121 */       scaledTickIncr = 2.0D;
/*     */     } else
/* 123 */       scaledTickIncr = 1.0D;
/* 124 */     this.mTickIncrement = (scaledTickIncr * scale);
/*     */     
/* 126 */     if (!useGivenEndPoints)
/*     */     {
/* 128 */       double minorTickIncrement = this.mTickIncrement / 5.0D;
/* 129 */       double dval = this.mMaxVal / minorTickIncrement;
/* 130 */       int ival = (int)dval;
/* 131 */       if (ival != dval) {
/* 132 */         this.mMaxVal = ((ival + 1) * minorTickIncrement);
/*     */       }
/*     */       
/* 135 */       ival = (int)(this.mMinVal / this.mTickIncrement);
/* 136 */       this.mMinVal = (ival * this.mTickIncrement);
/* 137 */       this.mMinMajorTick = this.mMinVal;
/*     */     } else {
/* 139 */       int ival = (int)(this.mMinVal / this.mTickIncrement);
/* 140 */       this.mMinMajorTick = (ival * this.mTickIncrement);
/* 141 */       if (this.mMinMajorTick < this.mMinVal) {
/* 142 */         this.mMinMajorTick += this.mTickIncrement;
/*     */       }
/*     */     }
/* 145 */     this.mRangeVal = (this.mMaxVal - this.mMinVal);
/* 146 */     this.mPixelsPerRange = (this.mNumPixels / this.mRangeVal);
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/TickScaler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
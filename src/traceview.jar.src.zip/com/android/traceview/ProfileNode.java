/*    */ package com.android.traceview;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProfileNode
/*    */ {
/*    */   private String mLabel;
/*    */   
/*    */ 
/*    */ 
/*    */   private MethodData mMethodData;
/*    */   
/*    */ 
/*    */ 
/*    */   private ProfileData[] mChildren;
/*    */   
/*    */ 
/*    */ 
/*    */   private boolean mIsParent;
/*    */   
/*    */ 
/*    */   private boolean mIsRecursive;
/*    */   
/*    */ 
/*    */ 
/*    */   public ProfileNode(String label, MethodData methodData, ProfileData[] children, boolean isParent, boolean isRecursive)
/*    */   {
/* 29 */     this.mLabel = label;
/* 30 */     this.mMethodData = methodData;
/* 31 */     this.mChildren = children;
/* 32 */     this.mIsParent = isParent;
/* 33 */     this.mIsRecursive = isRecursive;
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 37 */     return this.mLabel;
/*    */   }
/*    */   
/*    */   public ProfileData[] getChildren() {
/* 41 */     return this.mChildren;
/*    */   }
/*    */   
/*    */   public boolean isParent() {
/* 45 */     return this.mIsParent;
/*    */   }
/*    */   
/*    */   public boolean isRecursive() {
/* 49 */     return this.mIsRecursive;
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ProfileNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
/*    */ package com.android.traceview;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProfileSelf
/*    */   extends ProfileData
/*    */ {
/*    */   public ProfileSelf(MethodData methodData)
/*    */   {
/* 21 */     this.mElement = methodData;
/* 22 */     this.mContext = methodData;
/*    */   }
/*    */   
/*    */   public String getProfileName()
/*    */   {
/* 27 */     return "self";
/*    */   }
/*    */   
/*    */   public long getElapsedInclusiveCpuTime()
/*    */   {
/* 32 */     return this.mElement.getTopExclusiveCpuTime();
/*    */   }
/*    */   
/*    */   public long getElapsedInclusiveRealTime()
/*    */   {
/* 37 */     return this.mElement.getTopExclusiveRealTime();
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ProfileSelf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
/*     */ package com.android.traceview;
/*     */ 
/*     */ import com.android.utils.SdkUtils;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jface.viewers.IColorProvider;
/*     */ import org.eclipse.jface.viewers.ITableLabelProvider;
/*     */ import org.eclipse.jface.viewers.ITreeContentProvider;
/*     */ import org.eclipse.jface.viewers.LabelProvider;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeColumn;
/*     */ import org.eclipse.swt.widgets.TreeItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ProfileProvider
/*     */   implements ITreeContentProvider
/*     */ {
/*     */   private MethodData[] mRoots;
/*     */   private SelectionAdapter mListener;
/*     */   private TreeViewer mTreeViewer;
/*     */   private TraceReader mReader;
/*     */   private Image mSortUp;
/*     */   private Image mSortDown;
/*  48 */   private String[] mColumnNames = { "Name", "Incl Cpu Time %", "Incl Cpu Time", "Excl Cpu Time %", "Excl Cpu Time", "Incl Real Time %", "Incl Real Time", "Excl Real Time %", "Excl Real Time", "Calls+Recur\nCalls/Total", "Cpu Time/Call", "Real Time/Call" };
/*     */   
/*     */ 
/*     */ 
/*  52 */   private int[] mColumnWidths = { 370, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100 };
/*     */   
/*     */ 
/*     */ 
/*  56 */   private int[] mColumnAlignments = { 16384, 131072, 131072, 131072, 131072, 131072, 131072, 131072, 131072, 16777216, 131072, 131072 };
/*     */   
/*     */   private static final int COL_NAME = 0;
/*     */   
/*     */   private static final int COL_INCLUSIVE_CPU_TIME_PER = 1;
/*     */   
/*     */   private static final int COL_INCLUSIVE_CPU_TIME = 2;
/*     */   private static final int COL_EXCLUSIVE_CPU_TIME_PER = 3;
/*     */   private static final int COL_EXCLUSIVE_CPU_TIME = 4;
/*     */   private static final int COL_INCLUSIVE_REAL_TIME_PER = 5;
/*     */   private static final int COL_INCLUSIVE_REAL_TIME = 6;
/*     */   private static final int COL_EXCLUSIVE_REAL_TIME_PER = 7;
/*     */   private static final int COL_EXCLUSIVE_REAL_TIME = 8;
/*     */   private static final int COL_CALLS = 9;
/*     */   private static final int COL_CPU_TIME_PER_CALL = 10;
/*     */   private static final int COL_REAL_TIME_PER_CALL = 11;
/*     */   private long mTotalCpuTime;
/*     */   private long mTotalRealTime;
/*  74 */   private int mPrevMatchIndex = -1;
/*     */   
/*     */   public ProfileProvider(TraceReader reader) {
/*  77 */     this.mRoots = reader.getMethods();
/*  78 */     this.mReader = reader;
/*  79 */     this.mTotalCpuTime = reader.getTotalCpuTime();
/*  80 */     this.mTotalRealTime = reader.getTotalRealTime();
/*  81 */     Display display = Display.getCurrent();
/*  82 */     InputStream in = getClass().getClassLoader().getResourceAsStream("icons/sort_up.png");
/*     */     
/*  84 */     this.mSortUp = new Image(display, in);
/*  85 */     in = getClass().getClassLoader().getResourceAsStream("icons/sort_down.png");
/*     */     
/*  87 */     this.mSortDown = new Image(display, in);
/*     */   }
/*     */   
/*     */   private MethodData doMatchName(String name, int startIndex)
/*     */   {
/*  92 */     boolean hasUpper = SdkUtils.hasUpperCaseCharacter(name);
/*  93 */     for (int ii = startIndex; ii < this.mRoots.length; ii++) {
/*  94 */       MethodData md = this.mRoots[ii];
/*  95 */       String fullName = md.getName();
/*     */       
/*     */ 
/*  98 */       if (!hasUpper)
/*  99 */         fullName = fullName.toLowerCase();
/* 100 */       if (fullName.indexOf(name) != -1) {
/* 101 */         this.mPrevMatchIndex = ii;
/* 102 */         return md;
/*     */       }
/*     */     }
/* 105 */     this.mPrevMatchIndex = -1;
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   public MethodData findMatchingName(String name) {
/* 110 */     return doMatchName(name, 0);
/*     */   }
/*     */   
/*     */   public MethodData findNextMatchingName(String name) {
/* 114 */     return doMatchName(name, this.mPrevMatchIndex + 1);
/*     */   }
/*     */   
/*     */   public MethodData findMatchingTreeItem(TreeItem item) {
/* 118 */     if (item == null)
/* 119 */       return null;
/* 120 */     String text = item.getText();
/* 121 */     if (!Character.isDigit(text.charAt(0)))
/* 122 */       return null;
/* 123 */     int spaceIndex = text.indexOf(' ');
/* 124 */     String numstr = text.substring(0, spaceIndex);
/* 125 */     int rank = Integer.valueOf(numstr).intValue();
/* 126 */     for (MethodData md : this.mRoots) {
/* 127 */       if (md.getRank() == rank)
/* 128 */         return md;
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public void setTreeViewer(TreeViewer treeViewer) {
/* 134 */     this.mTreeViewer = treeViewer;
/*     */   }
/*     */   
/*     */   public String[] getColumnNames() {
/* 138 */     return this.mColumnNames;
/*     */   }
/*     */   
/*     */   public int[] getColumnWidths() {
/* 142 */     int[] widths = Arrays.copyOf(this.mColumnWidths, this.mColumnWidths.length);
/* 143 */     if (!this.mReader.haveCpuTime()) {
/* 144 */       widths[4] = 0;
/* 145 */       widths[3] = 0;
/* 146 */       widths[2] = 0;
/* 147 */       widths[1] = 0;
/* 148 */       widths[10] = 0;
/*     */     }
/* 150 */     if (!this.mReader.haveRealTime()) {
/* 151 */       widths[8] = 0;
/* 152 */       widths[7] = 0;
/* 153 */       widths[6] = 0;
/* 154 */       widths[5] = 0;
/* 155 */       widths[11] = 0;
/*     */     }
/* 157 */     return widths;
/*     */   }
/*     */   
/*     */   public int[] getColumnAlignments() {
/* 161 */     return this.mColumnAlignments;
/*     */   }
/*     */   
/*     */   public Object[] getChildren(Object element)
/*     */   {
/* 166 */     if ((element instanceof MethodData)) {
/* 167 */       MethodData md = (MethodData)element;
/* 168 */       return md.getProfileNodes();
/*     */     }
/* 170 */     if ((element instanceof ProfileNode)) {
/* 171 */       ProfileNode pn = (ProfileNode)element;
/* 172 */       return pn.getChildren();
/*     */     }
/* 174 */     return new Object[0];
/*     */   }
/*     */   
/*     */   public Object getParent(Object element)
/*     */   {
/* 179 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasChildren(Object element)
/*     */   {
/* 184 */     if ((element instanceof MethodData))
/* 185 */       return true;
/* 186 */     if ((element instanceof ProfileNode))
/* 187 */       return true;
/* 188 */     return false;
/*     */   }
/*     */   
/*     */   public Object[] getElements(Object element)
/*     */   {
/* 193 */     return this.mRoots;
/*     */   }
/*     */   
/*     */ 
/*     */   public void dispose() {}
/*     */   
/*     */ 
/*     */   public void inputChanged(Viewer arg0, Object arg1, Object arg2) {}
/*     */   
/*     */ 
/*     */   public Object getRoot()
/*     */   {
/* 205 */     return "root";
/*     */   }
/*     */   
/*     */   public SelectionAdapter getColumnListener() {
/* 209 */     if (this.mListener == null)
/* 210 */       this.mListener = new ColumnListener();
/* 211 */     return this.mListener;
/*     */   }
/*     */   
/*     */   public LabelProvider getLabelProvider() {
/* 215 */     return new ProfileLabelProvider();
/*     */   }
/*     */   
/*     */   class ProfileLabelProvider extends LabelProvider implements ITableLabelProvider, IColorProvider
/*     */   {
/*     */     Color colorRed;
/*     */     Color colorParentsBack;
/*     */     Color colorChildrenBack;
/*     */     TraceUnits traceUnits;
/*     */     
/*     */     public ProfileLabelProvider() {
/* 226 */       Display display = Display.getCurrent();
/* 227 */       this.colorRed = display.getSystemColor(3);
/* 228 */       this.colorParentsBack = new Color(display, 230, 230, 255);
/* 229 */       this.colorChildrenBack = new Color(display, 255, 255, 210);
/* 230 */       this.traceUnits = ProfileProvider.this.mReader.getTraceUnits();
/*     */     }
/*     */     
/*     */     public String getColumnText(Object element, int col)
/*     */     {
/* 235 */       if ((element instanceof MethodData)) {
/* 236 */         MethodData md = (MethodData)element;
/* 237 */         if (col == 0)
/* 238 */           return md.getProfileName();
/* 239 */         if (col == 4) {
/* 240 */           double val = md.getElapsedExclusiveCpuTime();
/* 241 */           val = this.traceUnits.getScaledValue(val);
/* 242 */           return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */         }
/* 244 */         if (col == 3) {
/* 245 */           double val = md.getElapsedExclusiveCpuTime();
/* 246 */           double per = val * 100.0D / ProfileProvider.this.mTotalCpuTime;
/* 247 */           return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */         }
/* 249 */         if (col == 2) {
/* 250 */           double val = md.getElapsedInclusiveCpuTime();
/* 251 */           val = this.traceUnits.getScaledValue(val);
/* 252 */           return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */         }
/* 254 */         if (col == 1) {
/* 255 */           double val = md.getElapsedInclusiveCpuTime();
/* 256 */           double per = val * 100.0D / ProfileProvider.this.mTotalCpuTime;
/* 257 */           return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */         }
/* 259 */         if (col == 8) {
/* 260 */           double val = md.getElapsedExclusiveRealTime();
/* 261 */           val = this.traceUnits.getScaledValue(val);
/* 262 */           return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */         }
/* 264 */         if (col == 7) {
/* 265 */           double val = md.getElapsedExclusiveRealTime();
/* 266 */           double per = val * 100.0D / ProfileProvider.this.mTotalRealTime;
/* 267 */           return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */         }
/* 269 */         if (col == 6) {
/* 270 */           double val = md.getElapsedInclusiveRealTime();
/* 271 */           val = this.traceUnits.getScaledValue(val);
/* 272 */           return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */         }
/* 274 */         if (col == 5) {
/* 275 */           double val = md.getElapsedInclusiveRealTime();
/* 276 */           double per = val * 100.0D / ProfileProvider.this.mTotalRealTime;
/* 277 */           return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */         }
/* 279 */         if (col == 9)
/* 280 */           return md.getCalls();
/* 281 */         if (col == 10) {
/* 282 */           int numCalls = md.getTotalCalls();
/* 283 */           double val = md.getElapsedInclusiveCpuTime();
/* 284 */           val /= numCalls;
/* 285 */           val = this.traceUnits.getScaledValue(val);
/* 286 */           return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */         }
/* 288 */         if (col == 11) {
/* 289 */           int numCalls = md.getTotalCalls();
/* 290 */           double val = md.getElapsedInclusiveRealTime();
/* 291 */           val /= numCalls;
/* 292 */           val = this.traceUnits.getScaledValue(val);
/* 293 */           return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */         }
/* 295 */       } else { if ((element instanceof ProfileSelf)) {
/* 296 */           ProfileSelf ps = (ProfileSelf)element;
/* 297 */           if (col == 0)
/* 298 */             return ps.getProfileName();
/* 299 */           if (col == 2) {
/* 300 */             double val = ps.getElapsedInclusiveCpuTime();
/* 301 */             val = this.traceUnits.getScaledValue(val);
/* 302 */             return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */           }
/* 304 */           if (col == 1)
/*     */           {
/* 306 */             double val = ps.getElapsedInclusiveCpuTime();
/* 307 */             MethodData context = ps.getContext();
/* 308 */             double total = context.getElapsedInclusiveCpuTime();
/* 309 */             double per = val * 100.0D / total;
/* 310 */             return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */           }
/* 312 */           if (col == 6) {
/* 313 */             double val = ps.getElapsedInclusiveRealTime();
/* 314 */             val = this.traceUnits.getScaledValue(val);
/* 315 */             return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */           }
/* 317 */           if (col == 5)
/*     */           {
/* 319 */             double val = ps.getElapsedInclusiveRealTime();
/* 320 */             MethodData context = ps.getContext();
/* 321 */             double total = context.getElapsedInclusiveRealTime();
/* 322 */             double per = val * 100.0D / total;
/* 323 */             return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */           }
/* 325 */           return ""; }
/* 326 */         if ((element instanceof ProfileData)) {
/* 327 */           ProfileData pd = (ProfileData)element;
/* 328 */           if (col == 0)
/* 329 */             return pd.getProfileName();
/* 330 */           if (col == 2) {
/* 331 */             double val = pd.getElapsedInclusiveCpuTime();
/* 332 */             val = this.traceUnits.getScaledValue(val);
/* 333 */             return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */           }
/* 335 */           if (col == 1)
/*     */           {
/* 337 */             double val = pd.getElapsedInclusiveCpuTime();
/* 338 */             MethodData context = pd.getContext();
/* 339 */             double total = context.getElapsedInclusiveCpuTime();
/* 340 */             double per = val * 100.0D / total;
/* 341 */             return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */           }
/* 343 */           if (col == 6) {
/* 344 */             double val = pd.getElapsedInclusiveRealTime();
/* 345 */             val = this.traceUnits.getScaledValue(val);
/* 346 */             return String.format("%.3f", new Object[] { Double.valueOf(val) });
/*     */           }
/* 348 */           if (col == 5)
/*     */           {
/* 350 */             double val = pd.getElapsedInclusiveRealTime();
/* 351 */             MethodData context = pd.getContext();
/* 352 */             double total = context.getElapsedInclusiveRealTime();
/* 353 */             double per = val * 100.0D / total;
/* 354 */             return String.format("%.1f%%", new Object[] { Double.valueOf(per) });
/*     */           }
/* 356 */           if (col == 9)
/* 357 */             return pd.getNumCalls();
/* 358 */           return ""; }
/* 359 */         if ((element instanceof ProfileNode)) {
/* 360 */           ProfileNode pn = (ProfileNode)element;
/* 361 */           if (col == 0)
/* 362 */             return pn.getLabel();
/* 363 */           return "";
/*     */         } }
/* 365 */       return "col" + col;
/*     */     }
/*     */     
/*     */     public Image getColumnImage(Object element, int col)
/*     */     {
/* 370 */       if (col != 0)
/* 371 */         return null;
/* 372 */       if ((element instanceof MethodData)) {
/* 373 */         MethodData md = (MethodData)element;
/* 374 */         return md.getImage();
/*     */       }
/* 376 */       if ((element instanceof ProfileData)) {
/* 377 */         ProfileData pd = (ProfileData)element;
/* 378 */         MethodData md = pd.getMethodData();
/* 379 */         return md.getImage();
/*     */       }
/* 381 */       return null;
/*     */     }
/*     */     
/*     */     public Color getForeground(Object element)
/*     */     {
/* 386 */       return null;
/*     */     }
/*     */     
/*     */     public Color getBackground(Object element)
/*     */     {
/* 391 */       if ((element instanceof ProfileData)) {
/* 392 */         ProfileData pd = (ProfileData)element;
/* 393 */         if (pd.isParent())
/* 394 */           return this.colorParentsBack;
/* 395 */         return this.colorChildrenBack;
/*     */       }
/* 397 */       if ((element instanceof ProfileNode)) {
/* 398 */         ProfileNode pn = (ProfileNode)element;
/* 399 */         if (pn.isParent())
/* 400 */           return this.colorParentsBack;
/* 401 */         return this.colorChildrenBack;
/*     */       }
/* 403 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   class ColumnListener extends SelectionAdapter {
/* 408 */     MethodData.Sorter sorter = new MethodData.Sorter();
/*     */     
/*     */     ColumnListener() {}
/*     */     
/* 412 */     public void widgetSelected(SelectionEvent event) { TreeColumn column = (TreeColumn)event.widget;
/* 413 */       String name = column.getText();
/* 414 */       Tree tree = column.getParent();
/* 415 */       tree.setRedraw(false);
/* 416 */       TreeColumn[] columns = tree.getColumns();
/* 417 */       for (TreeColumn col : columns) {
/* 418 */         col.setImage(null);
/*     */       }
/* 420 */       if (name == ProfileProvider.this.mColumnNames[0])
/*     */       {
/* 422 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_NAME);
/* 423 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 424 */       } else if (name == ProfileProvider.this.mColumnNames[4]) {
/* 425 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_EXCLUSIVE_CPU_TIME);
/* 426 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 427 */       } else if (name == ProfileProvider.this.mColumnNames[3]) {
/* 428 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_EXCLUSIVE_CPU_TIME);
/* 429 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 430 */       } else if (name == ProfileProvider.this.mColumnNames[2]) {
/* 431 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_INCLUSIVE_CPU_TIME);
/* 432 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 433 */       } else if (name == ProfileProvider.this.mColumnNames[1]) {
/* 434 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_INCLUSIVE_CPU_TIME);
/* 435 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 436 */       } else if (name == ProfileProvider.this.mColumnNames[8]) {
/* 437 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_EXCLUSIVE_REAL_TIME);
/* 438 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 439 */       } else if (name == ProfileProvider.this.mColumnNames[7]) {
/* 440 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_EXCLUSIVE_REAL_TIME);
/* 441 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 442 */       } else if (name == ProfileProvider.this.mColumnNames[6]) {
/* 443 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_INCLUSIVE_REAL_TIME);
/* 444 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 445 */       } else if (name == ProfileProvider.this.mColumnNames[5]) {
/* 446 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_INCLUSIVE_REAL_TIME);
/* 447 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 448 */       } else if (name == ProfileProvider.this.mColumnNames[9]) {
/* 449 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_CALLS);
/* 450 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 451 */       } else if (name == ProfileProvider.this.mColumnNames[10]) {
/* 452 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_CPU_TIME_PER_CALL);
/* 453 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/* 454 */       } else if (name == ProfileProvider.this.mColumnNames[11]) {
/* 455 */         this.sorter.setColumn(MethodData.Sorter.Column.BY_REAL_TIME_PER_CALL);
/* 456 */         Arrays.sort(ProfileProvider.this.mRoots, this.sorter);
/*     */       }
/* 458 */       MethodData.Sorter.Direction direction = this.sorter.getDirection();
/* 459 */       if (direction == MethodData.Sorter.Direction.INCREASING) {
/* 460 */         column.setImage(ProfileProvider.this.mSortDown);
/*     */       } else
/* 462 */         column.setImage(ProfileProvider.this.mSortUp);
/* 463 */       tree.setRedraw(true);
/* 464 */       ProfileProvider.this.mTreeViewer.refresh();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ProfileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
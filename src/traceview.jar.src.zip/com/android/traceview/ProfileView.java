/*     */ package com.android.traceview;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Observable;
/*     */ import java.util.Observer;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.ISelectionChangedListener;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.jface.viewers.ITreeViewerListener;
/*     */ import org.eclipse.jface.viewers.SelectionChangedEvent;
/*     */ import org.eclipse.jface.viewers.StructuredSelection;
/*     */ import org.eclipse.jface.viewers.TreeExpansionEvent;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.FontMetrics;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeColumn;
/*     */ import org.eclipse.swt.widgets.TreeItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProfileView
/*     */   extends Composite
/*     */   implements Observer
/*     */ {
/*     */   private TreeViewer mTreeViewer;
/*     */   private Text mSearchBox;
/*     */   private SelectionController mSelectionController;
/*     */   private ProfileProvider mProfileProvider;
/*     */   private Color mColorNoMatch;
/*     */   private Color mColorMatch;
/*     */   private MethodData mCurrentHighlightedMethod;
/*     */   private MethodHandler mMethodHandler;
/*     */   
/*     */   public ProfileView(Composite parent, TraceReader reader, SelectionController selectController)
/*     */   {
/*  68 */     super(parent, 0);
/*  69 */     setLayout(new GridLayout(1, false));
/*  70 */     this.mSelectionController = selectController;
/*  71 */     this.mSelectionController.addObserver(this);
/*     */     
/*     */ 
/*  74 */     this.mTreeViewer = new TreeViewer(this, 2);
/*  75 */     this.mTreeViewer.setUseHashlookup(true);
/*  76 */     this.mProfileProvider = reader.getProfileProvider();
/*  77 */     this.mProfileProvider.setTreeViewer(this.mTreeViewer);
/*  78 */     SelectionAdapter listener = this.mProfileProvider.getColumnListener();
/*  79 */     final Tree tree = this.mTreeViewer.getTree();
/*  80 */     tree.setHeaderVisible(true);
/*  81 */     tree.setLayoutData(new GridData(1808));
/*     */     
/*     */ 
/*  84 */     String[] columnNames = this.mProfileProvider.getColumnNames();
/*  85 */     int[] columnWidths = this.mProfileProvider.getColumnWidths();
/*  86 */     int[] columnAlignments = this.mProfileProvider.getColumnAlignments();
/*  87 */     for (int ii = 0; ii < columnWidths.length; ii++) {
/*  88 */       TreeColumn column = new TreeColumn(tree, 16384);
/*  89 */       column.setText(columnNames[ii]);
/*  90 */       column.setWidth(columnWidths[ii]);
/*  91 */       column.setMoveable(true);
/*  92 */       column.addSelectionListener(listener);
/*  93 */       column.setAlignment(columnAlignments[ii]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  98 */     tree.addListener(41, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 101 */         int fontHeight = event.gc.getFontMetrics().getHeight();
/* 102 */         event.height = fontHeight;
/*     */       }
/*     */       
/* 105 */     });
/* 106 */     this.mTreeViewer.setContentProvider(this.mProfileProvider);
/* 107 */     this.mTreeViewer.setLabelProvider(this.mProfileProvider.getLabelProvider());
/* 108 */     this.mTreeViewer.setInput(this.mProfileProvider.getRoot());
/*     */     
/*     */ 
/* 111 */     Composite composite = new Composite(this, 0);
/* 112 */     composite.setLayout(new GridLayout(2, false));
/* 113 */     composite.setLayoutData(new GridData(768));
/*     */     
/*     */ 
/* 116 */     Label label = new Label(composite, 0);
/* 117 */     label.setText("Find:");
/*     */     
/*     */ 
/* 120 */     this.mSearchBox = new Text(composite, 2048);
/* 121 */     this.mSearchBox.setLayoutData(new GridData(768));
/*     */     
/* 123 */     Display display = getDisplay();
/* 124 */     this.mColorNoMatch = new Color(display, 255, 200, 200);
/* 125 */     this.mColorMatch = this.mSearchBox.getBackground();
/*     */     
/* 127 */     this.mSearchBox.addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent ev) {
/* 130 */         String query = ProfileView.this.mSearchBox.getText();
/* 131 */         if (query.length() == 0)
/* 132 */           return;
/* 133 */         ProfileView.this.findName(query);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/* 138 */     });
/* 139 */     this.mSearchBox.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent event) {
/* 142 */         if (event.keyCode == 27) {
/* 143 */           ProfileView.this.mSearchBox.setText("");
/* 144 */         } else if (event.keyCode == 13) {
/* 145 */           String query = ProfileView.this.mSearchBox.getText();
/* 146 */           if (query.length() == 0)
/* 147 */             return;
/* 148 */           ProfileView.this.findNextName(query);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/* 154 */     });
/* 155 */     tree.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent event) {
/* 158 */         if (event.keyCode == 27) {
/* 159 */           ProfileView.this.mSearchBox.setText("");
/* 160 */         } else if (event.keyCode == 8)
/*     */         {
/* 162 */           String text = ProfileView.this.mSearchBox.getText();
/* 163 */           int len = text.length();
/*     */           String chopped;
/* 165 */           String chopped; if (len <= 1) {
/* 166 */             chopped = "";
/*     */           } else
/* 168 */             chopped = text.substring(0, len - 1);
/* 169 */           ProfileView.this.mSearchBox.setText(chopped);
/* 170 */         } else if (event.keyCode == 13) {
/* 171 */           String query = ProfileView.this.mSearchBox.getText();
/* 172 */           if (query.length() == 0)
/* 173 */             return;
/* 174 */           ProfileView.this.findNextName(query);
/*     */         }
/*     */         else {
/* 177 */           String str = String.valueOf(event.character);
/* 178 */           ProfileView.this.mSearchBox.append(str);
/*     */         }
/* 180 */         event.doit = false;
/*     */ 
/*     */       }
/*     */       
/*     */ 
/* 185 */     });
/* 186 */     this.mTreeViewer.addSelectionChangedListener(new ISelectionChangedListener()
/*     */     {
/*     */       public void selectionChanged(SelectionChangedEvent ev)
/*     */       {
/* 190 */         ISelection sel = ev.getSelection();
/* 191 */         if (sel.isEmpty())
/* 192 */           return;
/* 193 */         if ((sel instanceof IStructuredSelection)) {
/* 194 */           IStructuredSelection selection = (IStructuredSelection)sel;
/* 195 */           Object element = selection.getFirstElement();
/* 196 */           if (element == null)
/* 197 */             return;
/* 198 */           if ((element instanceof MethodData)) {
/* 199 */             MethodData md = (MethodData)element;
/* 200 */             ProfileView.this.highlightMethod(md, true);
/*     */           }
/* 202 */           if ((element instanceof ProfileData)) {
/* 203 */             MethodData md = ((ProfileData)element).getMethodData();
/*     */             
/* 205 */             ProfileView.this.highlightMethod(md, true);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 212 */     });
/* 213 */     this.mTreeViewer.addTreeListener(new ITreeViewerListener()
/*     */     {
/*     */       public void treeExpanded(TreeExpansionEvent event) {
/* 216 */         Object element = event.getElement();
/* 217 */         if ((element instanceof MethodData)) {
/* 218 */           MethodData md = (MethodData)element;
/* 219 */           ProfileView.this.expandNode(md);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void treeCollapsed(TreeExpansionEvent event) {}
/* 226 */     });
/* 227 */     tree.addListener(3, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 230 */         Point point = new Point(event.x, event.y);
/* 231 */         TreeItem treeItem = tree.getItem(point);
/* 232 */         MethodData md = ProfileView.this.mProfileProvider.findMatchingTreeItem(treeItem);
/* 233 */         if (md == null)
/* 234 */           return;
/* 235 */         ArrayList<Selection> selections = new ArrayList();
/* 236 */         selections.add(Selection.highlight("MethodData", md));
/* 237 */         ProfileView.this.mSelectionController.change(selections, "ProfileView");
/*     */         
/* 239 */         if ((ProfileView.this.mMethodHandler != null) && ((event.stateMask & SWT.MOD1) != 0)) {
/* 240 */           ProfileView.this.mMethodHandler.handleMethod(md);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void setMethodHandler(MethodHandler handler) {
/* 247 */     this.mMethodHandler = handler;
/*     */   }
/*     */   
/*     */   private void findName(String query) {
/* 251 */     MethodData md = this.mProfileProvider.findMatchingName(query);
/* 252 */     selectMethod(md);
/*     */   }
/*     */   
/*     */   private void findNextName(String query) {
/* 256 */     MethodData md = this.mProfileProvider.findNextMatchingName(query);
/* 257 */     selectMethod(md);
/*     */   }
/*     */   
/*     */   private void selectMethod(MethodData md) {
/* 261 */     if (md == null) {
/* 262 */       this.mSearchBox.setBackground(this.mColorNoMatch);
/* 263 */       return;
/*     */     }
/* 265 */     this.mSearchBox.setBackground(this.mColorMatch);
/* 266 */     highlightMethod(md, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void update(Observable objservable, Object arg)
/*     */   {
/* 272 */     if (arg == "ProfileView") {
/* 273 */       return;
/*     */     }
/*     */     
/* 276 */     ArrayList<Selection> selections = this.mSelectionController.getSelections();
/* 277 */     for (Selection selection : selections) {
/* 278 */       Selection.Action action = selection.getAction();
/* 279 */       if (action == Selection.Action.Highlight)
/*     */       {
/* 281 */         String name = selection.getName();
/* 282 */         if (name == "MethodData") {
/* 283 */           MethodData md = (MethodData)selection.getValue();
/* 284 */           highlightMethod(md, true);
/* 285 */           return;
/*     */         }
/* 287 */         if (name == "Call") {
/* 288 */           Call call = (Call)selection.getValue();
/* 289 */           MethodData md = call.getMethodData();
/* 290 */           highlightMethod(md, true);
/* 291 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 297 */   private void highlightMethod(MethodData md, boolean clearSearch) { if (md == null) {
/* 298 */       return;
/*     */     }
/* 300 */     if (md == this.mCurrentHighlightedMethod)
/* 301 */       return;
/* 302 */     if (clearSearch) {
/* 303 */       this.mSearchBox.setText("");
/* 304 */       this.mSearchBox.setBackground(this.mColorMatch);
/*     */     }
/* 306 */     this.mCurrentHighlightedMethod = md;
/* 307 */     this.mTreeViewer.collapseAll();
/*     */     
/* 309 */     expandNode(md);
/* 310 */     StructuredSelection sel = new StructuredSelection(md);
/* 311 */     this.mTreeViewer.setSelection(sel, true);
/* 312 */     Tree tree = this.mTreeViewer.getTree();
/* 313 */     TreeItem[] items = tree.getSelection();
/* 314 */     if (items.length != 0) {
/* 315 */       tree.setTopItem(items[0]);
/*     */       
/* 317 */       tree.showItem(items[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void expandNode(MethodData md) {
/* 322 */     ProfileNode[] nodes = md.getProfileNodes();
/* 323 */     this.mTreeViewer.setExpandedState(md, true);
/*     */     
/* 325 */     if (nodes != null) {
/* 326 */       for (ProfileNode node : nodes) {
/* 327 */         if (!node.isRecursive()) {
/* 328 */           this.mTreeViewer.setExpandedState(node, true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface MethodHandler
/*     */   {
/*     */     public abstract void handleMethod(MethodData paramMethodData);
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ProfileView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
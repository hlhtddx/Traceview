/*     */ package com.android.traceview;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Call
/*     */   implements TimeLineView.Block
/*     */ {
/*     */   private final ThreadData mThreadData;
/*     */   private final MethodData mMethodData;
/*     */   final Call mCaller;
/*     */   private String mName;
/*     */   private boolean mIsRecursive;
/*     */   long mGlobalStartTime;
/*     */   long mGlobalEndTime;
/*     */   long mThreadStartTime;
/*     */   long mThreadEndTime;
/*     */   long mInclusiveRealTime;
/*     */   long mExclusiveRealTime;
/*     */   long mInclusiveCpuTime;
/*     */   long mExclusiveCpuTime;
/*     */   
/*     */   Call(ThreadData threadData, MethodData methodData, Call caller)
/*     */   {
/*  42 */     this.mThreadData = threadData;
/*  43 */     this.mMethodData = methodData;
/*  44 */     this.mName = methodData.getProfileName();
/*  45 */     this.mCaller = caller;
/*     */   }
/*     */   
/*     */   public void updateName() {
/*  49 */     this.mName = this.mMethodData.getProfileName();
/*     */   }
/*     */   
/*     */   public double addWeight(int x, int y, double weight)
/*     */   {
/*  54 */     return this.mMethodData.addWeight(x, y, weight);
/*     */   }
/*     */   
/*     */   public void clearWeight()
/*     */   {
/*  59 */     this.mMethodData.clearWeight();
/*     */   }
/*     */   
/*     */   public long getStartTime()
/*     */   {
/*  64 */     return this.mGlobalStartTime;
/*     */   }
/*     */   
/*     */   public long getEndTime()
/*     */   {
/*  69 */     return this.mGlobalEndTime;
/*     */   }
/*     */   
/*     */   public long getExclusiveCpuTime()
/*     */   {
/*  74 */     return this.mExclusiveCpuTime;
/*     */   }
/*     */   
/*     */   public long getInclusiveCpuTime()
/*     */   {
/*  79 */     return this.mInclusiveCpuTime;
/*     */   }
/*     */   
/*     */   public long getExclusiveRealTime()
/*     */   {
/*  84 */     return this.mExclusiveRealTime;
/*     */   }
/*     */   
/*     */   public long getInclusiveRealTime()
/*     */   {
/*  89 */     return this.mInclusiveRealTime;
/*     */   }
/*     */   
/*     */   public Color getColor()
/*     */   {
/*  94 */     return this.mMethodData.getColor();
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  99 */     return this.mName;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 103 */     this.mName = name;
/*     */   }
/*     */   
/*     */   public ThreadData getThreadData() {
/* 107 */     return this.mThreadData;
/*     */   }
/*     */   
/*     */   public int getThreadId() {
/* 111 */     return this.mThreadData.getId();
/*     */   }
/*     */   
/*     */   public MethodData getMethodData()
/*     */   {
/* 116 */     return this.mMethodData;
/*     */   }
/*     */   
/*     */   public boolean isContextSwitch()
/*     */   {
/* 121 */     return this.mMethodData.getId() == -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isIgnoredBlock()
/*     */   {
/* 127 */     return (this.mCaller == null) || ((isContextSwitch()) && (this.mCaller.mCaller == null));
/*     */   }
/*     */   
/*     */   public TimeLineView.Block getParentBlock()
/*     */   {
/* 132 */     return this.mCaller;
/*     */   }
/*     */   
/*     */   public boolean isRecursive() {
/* 136 */     return this.mIsRecursive;
/*     */   }
/*     */   
/*     */   void setRecursive(boolean isRecursive) {
/* 140 */     this.mIsRecursive = isRecursive;
/*     */   }
/*     */   
/*     */   void addCpuTime(long elapsedCpuTime) {
/* 144 */     this.mExclusiveCpuTime += elapsedCpuTime;
/* 145 */     this.mInclusiveCpuTime += elapsedCpuTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void finish()
/*     */   {
/* 152 */     if (this.mCaller != null) {
/* 153 */       this.mCaller.mInclusiveCpuTime += this.mInclusiveCpuTime;
/* 154 */       this.mCaller.mInclusiveRealTime += this.mInclusiveRealTime;
/*     */     }
/*     */     
/* 157 */     this.mMethodData.addElapsedExclusive(this.mExclusiveCpuTime, this.mExclusiveRealTime);
/* 158 */     if (!this.mIsRecursive) {
/* 159 */       this.mMethodData.addTopExclusive(this.mExclusiveCpuTime, this.mExclusiveRealTime);
/*     */     }
/* 161 */     this.mMethodData.addElapsedInclusive(this.mInclusiveCpuTime, this.mInclusiveRealTime, this.mIsRecursive, this.mCaller);
/*     */   }
/*     */   
/*     */   public static final class TraceAction
/*     */   {
/*     */     public static final int ACTION_ENTER = 0;
/*     */     public static final int ACTION_EXIT = 1;
/*     */     public final int mAction;
/*     */     public final Call mCall;
/*     */     
/*     */     public TraceAction(int action, Call call)
/*     */     {
/* 173 */       this.mAction = action;
/* 174 */       this.mCall = call;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/Call.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
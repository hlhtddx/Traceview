/*    */ package com.android.traceview;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract interface TimeBase
/*    */ {
/* 20 */   public static final TimeBase CPU_TIME = new CpuTimeBase();
/* 21 */   public static final TimeBase REAL_TIME = new RealTimeBase();
/*    */   
/*    */   public abstract long getTime(ThreadData paramThreadData);
/*    */   
/*    */   public abstract long getElapsedInclusiveTime(MethodData paramMethodData);
/*    */   
/*    */   public abstract long getElapsedExclusiveTime(MethodData paramMethodData);
/*    */   
/*    */   public abstract long getElapsedInclusiveTime(ProfileData paramProfileData);
/*    */   
/* 31 */   public static final class CpuTimeBase implements TimeBase { public long getTime(ThreadData threadData) { return threadData.getCpuTime(); }
/*    */     
/*    */ 
/*    */     public long getElapsedInclusiveTime(MethodData methodData)
/*    */     {
/* 36 */       return methodData.getElapsedInclusiveCpuTime();
/*    */     }
/*    */     
/*    */     public long getElapsedExclusiveTime(MethodData methodData)
/*    */     {
/* 41 */       return methodData.getElapsedExclusiveCpuTime();
/*    */     }
/*    */     
/*    */     public long getElapsedInclusiveTime(ProfileData profileData)
/*    */     {
/* 46 */       return profileData.getElapsedInclusiveCpuTime();
/*    */     }
/*    */   }
/*    */   
/*    */   public static final class RealTimeBase implements TimeBase
/*    */   {
/*    */     public long getTime(ThreadData threadData) {
/* 53 */       return threadData.getRealTime();
/*    */     }
/*    */     
/*    */     public long getElapsedInclusiveTime(MethodData methodData)
/*    */     {
/* 58 */       return methodData.getElapsedInclusiveRealTime();
/*    */     }
/*    */     
/*    */     public long getElapsedExclusiveTime(MethodData methodData)
/*    */     {
/* 63 */       return methodData.getElapsedExclusiveRealTime();
/*    */     }
/*    */     
/*    */     public long getElapsedInclusiveTime(ProfileData profileData)
/*    */     {
/* 68 */       return profileData.getElapsedInclusiveRealTime();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/TimeBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
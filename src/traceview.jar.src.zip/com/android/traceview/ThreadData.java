/*     */ package com.android.traceview;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThreadData
/*     */   implements TimeLineView.Row
/*     */ {
/*     */   private int mId;
/*     */   private String mName;
/*     */   private boolean mIsEmpty;
/*     */   private Call mRootCall;
/*  29 */   private ArrayList<Call> mStack = new ArrayList();
/*     */   
/*     */ 
/*  32 */   private HashMap<MethodData, Integer> mStackMethods = new HashMap();
/*     */   
/*     */   boolean mHaveGlobalTime;
/*     */   
/*     */   long mGlobalStartTime;
/*     */   long mGlobalEndTime;
/*     */   boolean mHaveThreadTime;
/*     */   long mThreadStartTime;
/*     */   long mThreadEndTime;
/*     */   long mThreadCurrentTime;
/*     */   
/*     */   ThreadData(int id, String name, MethodData topLevel)
/*     */   {
/*  45 */     this.mId = id;
/*  46 */     this.mName = String.format("[%d] %s", new Object[] { Integer.valueOf(id), name });
/*  47 */     this.mIsEmpty = true;
/*  48 */     this.mRootCall = new Call(this, topLevel, null);
/*  49 */     this.mRootCall.setName(this.mName);
/*  50 */     this.mStack.add(this.mRootCall);
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  55 */     return this.mName;
/*     */   }
/*     */   
/*     */   public Call getRootCall() {
/*  59 */     return this.mRootCall;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  66 */     return this.mIsEmpty;
/*     */   }
/*     */   
/*     */   Call enter(MethodData method, ArrayList<TraceAction> trace) {
/*  70 */     if (this.mIsEmpty) {
/*  71 */       this.mIsEmpty = false;
/*  72 */       if (trace != null) {
/*  73 */         trace.add(new TraceAction(0, this.mRootCall));
/*     */       }
/*     */     }
/*     */     
/*  77 */     Call caller = top();
/*  78 */     Call call = new Call(this, method, caller);
/*  79 */     this.mStack.add(call);
/*     */     
/*  81 */     if (trace != null) {
/*  82 */       trace.add(new TraceAction(0, call));
/*     */     }
/*     */     
/*  85 */     Integer num = (Integer)this.mStackMethods.get(method);
/*  86 */     if (num == null) {
/*  87 */       num = Integer.valueOf(0);
/*  88 */     } else if (num.intValue() > 0) {
/*  89 */       call.setRecursive(true);
/*     */     }
/*  91 */     this.mStackMethods.put(method, Integer.valueOf(num.intValue() + 1));
/*     */     
/*  93 */     return call;
/*     */   }
/*     */   
/*     */   Call exit(MethodData method, ArrayList<TraceAction> trace) {
/*  97 */     Call call = top();
/*  98 */     if (call.mCaller == null) {
/*  99 */       return null;
/*     */     }
/*     */     
/* 102 */     if (call.getMethodData() != method) {
/* 103 */       String error = "Method exit (" + method.getName() + ") does not match current method (" + call.getMethodData().getName() + ")";
/*     */       
/*     */ 
/* 106 */       throw new RuntimeException(error);
/*     */     }
/*     */     
/* 109 */     this.mStack.remove(this.mStack.size() - 1);
/*     */     
/* 111 */     if (trace != null) {
/* 112 */       trace.add(new TraceAction(1, call));
/*     */     }
/*     */     
/* 115 */     Integer num = (Integer)this.mStackMethods.get(method);
/* 116 */     if (num != null) {
/* 117 */       if (num.intValue() == 1) {
/* 118 */         this.mStackMethods.remove(method);
/*     */       } else {
/* 120 */         this.mStackMethods.put(method, Integer.valueOf(num.intValue() - 1));
/*     */       }
/*     */     }
/*     */     
/* 124 */     return call;
/*     */   }
/*     */   
/*     */   Call top() {
/* 128 */     return (Call)this.mStack.get(this.mStack.size() - 1);
/*     */   }
/*     */   
/*     */   void endTrace(ArrayList<TraceAction> trace) {
/* 132 */     for (int i = this.mStack.size() - 1; i >= 1; i--) {
/* 133 */       Call call = (Call)this.mStack.get(i);
/* 134 */       call.mGlobalEndTime = this.mGlobalEndTime;
/* 135 */       call.mThreadEndTime = this.mThreadEndTime;
/* 136 */       if (trace != null) {
/* 137 */         trace.add(new TraceAction(2, call));
/*     */       }
/*     */     }
/* 140 */     this.mStack.clear();
/* 141 */     this.mStackMethods.clear();
/*     */   }
/*     */   
/*     */   void updateRootCallTimeBounds() {
/* 145 */     if (!this.mIsEmpty) {
/* 146 */       this.mRootCall.mGlobalStartTime = this.mGlobalStartTime;
/* 147 */       this.mRootCall.mGlobalEndTime = this.mGlobalEndTime;
/* 148 */       this.mRootCall.mThreadStartTime = this.mThreadStartTime;
/* 149 */       this.mRootCall.mThreadEndTime = this.mThreadEndTime;
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 155 */     return this.mName;
/*     */   }
/*     */   
/*     */   public int getId()
/*     */   {
/* 160 */     return this.mId;
/*     */   }
/*     */   
/*     */   public long getCpuTime() {
/* 164 */     return this.mRootCall.mInclusiveCpuTime;
/*     */   }
/*     */   
/*     */   public long getRealTime() {
/* 168 */     return this.mRootCall.mInclusiveRealTime;
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ThreadData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
/*     */ package com.android.traceview;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodData
/*     */ {
/*     */   private int mId;
/*  31 */   private int mRank = -1;
/*     */   private String mClassName;
/*     */   private String mMethodName;
/*     */   private String mSignature;
/*     */   private String mName;
/*     */   private String mProfileName;
/*     */   private String mPathname;
/*     */   private int mLineNumber;
/*     */   private long mElapsedExclusiveCpuTime;
/*     */   private long mElapsedInclusiveCpuTime;
/*     */   private long mTopExclusiveCpuTime;
/*     */   private long mElapsedExclusiveRealTime;
/*     */   private long mElapsedInclusiveRealTime;
/*     */   private long mTopExclusiveRealTime;
/*  45 */   private int[] mNumCalls = new int[2];
/*     */   
/*     */   private Color mColor;
/*     */   
/*     */   private Color mFadedColor;
/*     */   
/*     */   private Image mImage;
/*     */   
/*     */   private Image mFadedImage;
/*     */   private HashMap<Integer, ProfileData> mParents;
/*     */   private HashMap<Integer, ProfileData> mChildren;
/*     */   private HashMap<Integer, ProfileData> mRecursiveParents;
/*     */   private HashMap<Integer, ProfileData> mRecursiveChildren;
/*     */   private ProfileNode[] mProfileNodes;
/*     */   private int mX;
/*     */   private int mY;
/*     */   private double mWeight;
/*     */   
/*     */   public MethodData(int id, String className)
/*     */   {
/*  65 */     this.mId = id;
/*  66 */     this.mClassName = className;
/*  67 */     this.mMethodName = null;
/*  68 */     this.mSignature = null;
/*  69 */     this.mPathname = null;
/*  70 */     this.mLineNumber = -1;
/*  71 */     computeName();
/*  72 */     computeProfileName();
/*     */   }
/*     */   
/*     */   public MethodData(int id, String className, String methodName, String signature, String pathname, int lineNumber)
/*     */   {
/*  77 */     this.mId = id;
/*  78 */     this.mClassName = className;
/*  79 */     this.mMethodName = methodName;
/*  80 */     this.mSignature = signature;
/*  81 */     this.mPathname = pathname;
/*  82 */     this.mLineNumber = lineNumber;
/*  83 */     computeName();
/*  84 */     computeProfileName();
/*     */   }
/*     */   
/*     */   public double addWeight(int x, int y, double weight) {
/*  88 */     if ((this.mX == x) && (this.mY == y)) {
/*  89 */       this.mWeight += weight;
/*     */     } else {
/*  91 */       this.mX = x;
/*  92 */       this.mY = y;
/*  93 */       this.mWeight = weight;
/*     */     }
/*  95 */     return this.mWeight;
/*     */   }
/*     */   
/*     */   public void clearWeight() {
/*  99 */     this.mWeight = 0.0D;
/*     */   }
/*     */   
/*     */   public int getRank() {
/* 103 */     return this.mRank;
/*     */   }
/*     */   
/*     */   public void setRank(int rank) {
/* 107 */     this.mRank = rank;
/* 108 */     computeProfileName();
/*     */   }
/*     */   
/*     */   public void addElapsedExclusive(long cpuTime, long realTime) {
/* 112 */     this.mElapsedExclusiveCpuTime += cpuTime;
/* 113 */     this.mElapsedExclusiveRealTime += realTime;
/*     */   }
/*     */   
/*     */   public void addElapsedInclusive(long cpuTime, long realTime, boolean isRecursive, Call parent)
/*     */   {
/* 118 */     if (!isRecursive) {
/* 119 */       this.mElapsedInclusiveCpuTime += cpuTime;
/* 120 */       this.mElapsedInclusiveRealTime += realTime;
/* 121 */       this.mNumCalls[0] += 1;
/*     */     } else {
/* 123 */       this.mNumCalls[1] += 1;
/*     */     }
/*     */     
/* 126 */     if (parent == null) {
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     MethodData parentMethod = parent.getMethodData();
/* 131 */     if (parent.isRecursive()) {
/* 132 */       parentMethod.mRecursiveChildren = updateInclusive(cpuTime, realTime, parentMethod, this, false, parentMethod.mRecursiveChildren);
/*     */     }
/*     */     else
/*     */     {
/* 136 */       parentMethod.mChildren = updateInclusive(cpuTime, realTime, parentMethod, this, false, parentMethod.mChildren);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 141 */     if (isRecursive) {
/* 142 */       this.mRecursiveParents = updateInclusive(cpuTime, realTime, this, parentMethod, true, this.mRecursiveParents);
/*     */     }
/*     */     else {
/* 145 */       this.mParents = updateInclusive(cpuTime, realTime, this, parentMethod, true, this.mParents);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private HashMap<Integer, ProfileData> updateInclusive(long cpuTime, long realTime, MethodData contextMethod, MethodData elementMethod, boolean elementIsParent, HashMap<Integer, ProfileData> map)
/*     */   {
/* 153 */     if (map == null) {
/* 154 */       map = new HashMap(4);
/*     */     } else {
/* 156 */       ProfileData profileData = (ProfileData)map.get(Integer.valueOf(elementMethod.mId));
/* 157 */       if (profileData != null) {
/* 158 */         profileData.addElapsedInclusive(cpuTime, realTime);
/* 159 */         return map;
/*     */       }
/*     */     }
/*     */     
/* 163 */     ProfileData elementData = new ProfileData(contextMethod, elementMethod, elementIsParent);
/*     */     
/* 165 */     elementData.setElapsedInclusive(cpuTime, realTime);
/* 166 */     elementData.setNumCalls(1);
/* 167 */     map.put(Integer.valueOf(elementMethod.mId), elementData);
/* 168 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void analyzeData(TimeBase timeBase)
/*     */   {
/* 178 */     ProfileData[] sortedParents = sortProfileData(this.mParents, timeBase);
/* 179 */     ProfileData[] sortedChildren = sortProfileData(this.mChildren, timeBase);
/* 180 */     ProfileData[] sortedRecursiveParents = sortProfileData(this.mRecursiveParents, timeBase);
/* 181 */     ProfileData[] sortedRecursiveChildren = sortProfileData(this.mRecursiveChildren, timeBase);
/*     */     
/*     */ 
/* 184 */     sortedChildren = addSelf(sortedChildren);
/*     */     
/*     */ 
/* 187 */     ArrayList<ProfileNode> nodes = new ArrayList();
/*     */     
/* 189 */     if (this.mParents != null) {
/* 190 */       ProfileNode profileNode = new ProfileNode("Parents", this, sortedParents, true, false);
/*     */       
/* 192 */       nodes.add(profileNode);
/*     */     }
/* 194 */     if (this.mChildren != null) {
/* 195 */       ProfileNode profileNode = new ProfileNode("Children", this, sortedChildren, false, false);
/*     */       
/* 197 */       nodes.add(profileNode);
/*     */     }
/* 199 */     if (this.mRecursiveParents != null) {
/* 200 */       ProfileNode profileNode = new ProfileNode("Parents while recursive", this, sortedRecursiveParents, true, true);
/*     */       
/* 202 */       nodes.add(profileNode);
/*     */     }
/* 204 */     if (this.mRecursiveChildren != null) {
/* 205 */       ProfileNode profileNode = new ProfileNode("Children while recursive", this, sortedRecursiveChildren, false, true);
/*     */       
/* 207 */       nodes.add(profileNode);
/*     */     }
/* 209 */     this.mProfileNodes = ((ProfileNode[])nodes.toArray(new ProfileNode[nodes.size()]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ProfileData[] sortProfileData(HashMap<Integer, ProfileData> map, final TimeBase timeBase)
/*     */   {
/* 216 */     if (map == null) {
/* 217 */       return null;
/*     */     }
/*     */     
/* 220 */     Collection<ProfileData> values = map.values();
/* 221 */     ProfileData[] sorted = (ProfileData[])values.toArray(new ProfileData[values.size()]);
/*     */     
/*     */ 
/* 224 */     Arrays.sort(sorted, new Comparator()
/*     */     {
/*     */       public int compare(ProfileData pd1, ProfileData pd2) {
/* 227 */         if (timeBase.getElapsedInclusiveTime(pd2) > timeBase.getElapsedInclusiveTime(pd1))
/* 228 */           return 1;
/* 229 */         if (timeBase.getElapsedInclusiveTime(pd2) < timeBase.getElapsedInclusiveTime(pd1))
/* 230 */           return -1;
/* 231 */         return 0;
/*     */       }
/* 233 */     });
/* 234 */     return sorted;
/*     */   }
/*     */   
/*     */   private ProfileData[] addSelf(ProfileData[] children) { ProfileData[] pdata;
/*     */     ProfileData[] pdata;
/* 239 */     if (children == null) {
/* 240 */       pdata = new ProfileData[1];
/*     */     } else {
/* 242 */       pdata = new ProfileData[children.length + 1];
/* 243 */       System.arraycopy(children, 0, pdata, 1, children.length);
/*     */     }
/* 245 */     pdata[0] = new ProfileSelf(this);
/* 246 */     return pdata;
/*     */   }
/*     */   
/*     */   public void addTopExclusive(long cpuTime, long realTime) {
/* 250 */     this.mTopExclusiveCpuTime += cpuTime;
/* 251 */     this.mTopExclusiveRealTime += realTime;
/*     */   }
/*     */   
/*     */   public long getTopExclusiveCpuTime() {
/* 255 */     return this.mTopExclusiveCpuTime;
/*     */   }
/*     */   
/*     */   public long getTopExclusiveRealTime() {
/* 259 */     return this.mTopExclusiveRealTime;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 263 */     return this.mId;
/*     */   }
/*     */   
/*     */   private void computeName() {
/* 267 */     if (this.mMethodName == null) {
/* 268 */       this.mName = this.mClassName;
/* 269 */       return;
/*     */     }
/*     */     
/* 272 */     StringBuilder sb = new StringBuilder();
/* 273 */     sb.append(this.mClassName);
/* 274 */     sb.append(".");
/* 275 */     sb.append(this.mMethodName);
/* 276 */     sb.append(" ");
/* 277 */     sb.append(this.mSignature);
/* 278 */     this.mName = sb.toString();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 282 */     return this.mName;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 286 */     return this.mClassName;
/*     */   }
/*     */   
/*     */   public String getMethodName() {
/* 290 */     return this.mMethodName;
/*     */   }
/*     */   
/*     */   public String getProfileName() {
/* 294 */     return this.mProfileName;
/*     */   }
/*     */   
/*     */   public String getSignature() {
/* 298 */     return this.mSignature;
/*     */   }
/*     */   
/*     */   public void computeProfileName() {
/* 302 */     if (this.mRank == -1) {
/* 303 */       this.mProfileName = this.mName;
/* 304 */       return;
/*     */     }
/*     */     
/* 307 */     StringBuilder sb = new StringBuilder();
/* 308 */     sb.append(this.mRank);
/* 309 */     sb.append(" ");
/* 310 */     sb.append(getName());
/* 311 */     this.mProfileName = sb.toString();
/*     */   }
/*     */   
/*     */   public String getCalls() {
/* 315 */     return String.format("%d+%d", new Object[] { Integer.valueOf(this.mNumCalls[0]), Integer.valueOf(this.mNumCalls[1]) });
/*     */   }
/*     */   
/*     */   public int getTotalCalls() {
/* 319 */     return this.mNumCalls[0] + this.mNumCalls[1];
/*     */   }
/*     */   
/*     */   public Color getColor() {
/* 323 */     return this.mColor;
/*     */   }
/*     */   
/*     */   public void setColor(Color color) {
/* 327 */     this.mColor = color;
/*     */   }
/*     */   
/*     */   public void setImage(Image image) {
/* 331 */     this.mImage = image;
/*     */   }
/*     */   
/*     */   public Image getImage() {
/* 335 */     return this.mImage;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 340 */     return getName();
/*     */   }
/*     */   
/*     */   public long getElapsedExclusiveCpuTime() {
/* 344 */     return this.mElapsedExclusiveCpuTime;
/*     */   }
/*     */   
/*     */   public long getElapsedExclusiveRealTime() {
/* 348 */     return this.mElapsedExclusiveRealTime;
/*     */   }
/*     */   
/*     */   public long getElapsedInclusiveCpuTime() {
/* 352 */     return this.mElapsedInclusiveCpuTime;
/*     */   }
/*     */   
/*     */   public long getElapsedInclusiveRealTime() {
/* 356 */     return this.mElapsedInclusiveRealTime;
/*     */   }
/*     */   
/*     */   public void setFadedColor(Color fadedColor) {
/* 360 */     this.mFadedColor = fadedColor;
/*     */   }
/*     */   
/*     */   public Color getFadedColor() {
/* 364 */     return this.mFadedColor;
/*     */   }
/*     */   
/*     */   public void setFadedImage(Image fadedImage) {
/* 368 */     this.mFadedImage = fadedImage;
/*     */   }
/*     */   
/*     */   public Image getFadedImage() {
/* 372 */     return this.mFadedImage;
/*     */   }
/*     */   
/*     */   public void setPathname(String pathname) {
/* 376 */     this.mPathname = pathname;
/*     */   }
/*     */   
/*     */   public String getPathname() {
/* 380 */     return this.mPathname;
/*     */   }
/*     */   
/*     */   public void setLineNumber(int lineNumber) {
/* 384 */     this.mLineNumber = lineNumber;
/*     */   }
/*     */   
/*     */   public int getLineNumber() {
/* 388 */     return this.mLineNumber;
/*     */   }
/*     */   
/*     */ 
/* 392 */   public ProfileNode[] getProfileNodes() { return this.mProfileNodes; }
/*     */   
/*     */   public static class Sorter implements Comparator<MethodData> {
/*     */     private Column mColumn;
/*     */     private Direction mDirection;
/*     */     
/* 398 */     public int compare(MethodData md1, MethodData md2) { if (this.mColumn == Column.BY_NAME) {
/* 399 */         int result = md1.getName().compareTo(md2.getName());
/* 400 */         return this.mDirection == Direction.INCREASING ? result : -result;
/*     */       }
/* 402 */       if (this.mColumn == Column.BY_INCLUSIVE_CPU_TIME) {
/* 403 */         if (md2.getElapsedInclusiveCpuTime() > md1.getElapsedInclusiveCpuTime())
/* 404 */           return this.mDirection == Direction.INCREASING ? -1 : 1;
/* 405 */         if (md2.getElapsedInclusiveCpuTime() < md1.getElapsedInclusiveCpuTime())
/* 406 */           return this.mDirection == Direction.INCREASING ? 1 : -1;
/* 407 */         return md1.getName().compareTo(md2.getName());
/*     */       }
/* 409 */       if (this.mColumn == Column.BY_EXCLUSIVE_CPU_TIME) {
/* 410 */         if (md2.getElapsedExclusiveCpuTime() > md1.getElapsedExclusiveCpuTime())
/* 411 */           return this.mDirection == Direction.INCREASING ? -1 : 1;
/* 412 */         if (md2.getElapsedExclusiveCpuTime() < md1.getElapsedExclusiveCpuTime())
/* 413 */           return this.mDirection == Direction.INCREASING ? 1 : -1;
/* 414 */         return md1.getName().compareTo(md2.getName());
/*     */       }
/* 416 */       if (this.mColumn == Column.BY_INCLUSIVE_REAL_TIME) {
/* 417 */         if (md2.getElapsedInclusiveRealTime() > md1.getElapsedInclusiveRealTime())
/* 418 */           return this.mDirection == Direction.INCREASING ? -1 : 1;
/* 419 */         if (md2.getElapsedInclusiveRealTime() < md1.getElapsedInclusiveRealTime())
/* 420 */           return this.mDirection == Direction.INCREASING ? 1 : -1;
/* 421 */         return md1.getName().compareTo(md2.getName());
/*     */       }
/* 423 */       if (this.mColumn == Column.BY_EXCLUSIVE_REAL_TIME) {
/* 424 */         if (md2.getElapsedExclusiveRealTime() > md1.getElapsedExclusiveRealTime())
/* 425 */           return this.mDirection == Direction.INCREASING ? -1 : 1;
/* 426 */         if (md2.getElapsedExclusiveRealTime() < md1.getElapsedExclusiveRealTime())
/* 427 */           return this.mDirection == Direction.INCREASING ? 1 : -1;
/* 428 */         return md1.getName().compareTo(md2.getName());
/*     */       }
/* 430 */       if (this.mColumn == Column.BY_CALLS) {
/* 431 */         int result = md1.getTotalCalls() - md2.getTotalCalls();
/* 432 */         if (result == 0)
/* 433 */           return md1.getName().compareTo(md2.getName());
/* 434 */         return this.mDirection == Direction.INCREASING ? result : -result;
/*     */       }
/* 436 */       if (this.mColumn == Column.BY_CPU_TIME_PER_CALL) {
/* 437 */         double time1 = md1.getElapsedInclusiveCpuTime();
/* 438 */         time1 /= md1.getTotalCalls();
/* 439 */         double time2 = md2.getElapsedInclusiveCpuTime();
/* 440 */         time2 /= md2.getTotalCalls();
/* 441 */         double diff = time1 - time2;
/* 442 */         int result = 0;
/* 443 */         if (diff < 0.0D) {
/* 444 */           result = -1;
/* 445 */         } else if (diff > 0.0D)
/* 446 */           result = 1;
/* 447 */         if (result == 0)
/* 448 */           return md1.getName().compareTo(md2.getName());
/* 449 */         return this.mDirection == Direction.INCREASING ? result : -result;
/*     */       }
/* 451 */       if (this.mColumn == Column.BY_REAL_TIME_PER_CALL) {
/* 452 */         double time1 = md1.getElapsedInclusiveRealTime();
/* 453 */         time1 /= md1.getTotalCalls();
/* 454 */         double time2 = md2.getElapsedInclusiveRealTime();
/* 455 */         time2 /= md2.getTotalCalls();
/* 456 */         double diff = time1 - time2;
/* 457 */         int result = 0;
/* 458 */         if (diff < 0.0D) {
/* 459 */           result = -1;
/* 460 */         } else if (diff > 0.0D)
/* 461 */           result = 1;
/* 462 */         if (result == 0)
/* 463 */           return md1.getName().compareTo(md2.getName());
/* 464 */         return this.mDirection == Direction.INCREASING ? result : -result;
/*     */       }
/* 466 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */     public void setColumn(Column column)
/*     */     {
/* 472 */       if (this.mColumn == column)
/*     */       {
/* 474 */         if (this.mDirection == Direction.INCREASING) {
/* 475 */           this.mDirection = Direction.DECREASING;
/*     */         } else {
/* 477 */           this.mDirection = Direction.INCREASING;
/*     */         }
/*     */       }
/* 480 */       else if (column == Column.BY_NAME) {
/* 481 */         this.mDirection = Direction.INCREASING;
/*     */       } else {
/* 483 */         this.mDirection = Direction.DECREASING;
/*     */       }
/* 485 */       this.mColumn = column;
/*     */     }
/*     */     
/*     */     public Column getColumn() {
/* 489 */       return this.mColumn;
/*     */     }
/*     */     
/*     */     public void setDirection(Direction direction) {
/* 493 */       this.mDirection = direction;
/*     */     }
/*     */     
/*     */     public Direction getDirection() {
/* 497 */       return this.mDirection;
/*     */     }
/*     */     
/*     */     public static enum Column {
/* 501 */       BY_NAME,  BY_EXCLUSIVE_CPU_TIME,  BY_EXCLUSIVE_REAL_TIME, 
/* 502 */       BY_INCLUSIVE_CPU_TIME,  BY_INCLUSIVE_REAL_TIME,  BY_CALLS, 
/* 503 */       BY_REAL_TIME_PER_CALL,  BY_CPU_TIME_PER_CALL;
/*     */       
/*     */       private Column() {} }
/*     */     
/* 507 */     public static enum Direction { INCREASING,  DECREASING;
/*     */       
/*     */       private Direction() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/MethodData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
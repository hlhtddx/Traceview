/*     */ package com.android.traceview;
/*     */ 
/*     */ import com.android.sdkstats.SdkStatsService;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.action.MenuManager;
/*     */ import org.eclipse.jface.window.ApplicationWindow;
/*     */ import org.eclipse.swt.custom.SashForm;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MainWindow
/*     */   extends ApplicationWindow
/*     */ {
/*     */   private static final String PING_NAME = "Traceview";
/*     */   private TraceReader mReader;
/*     */   private String mTraceName;
/*  53 */   public static HashMap<String, String> sStringCache = new HashMap();
/*     */   
/*     */   public MainWindow(String traceName, TraceReader reader) {
/*  56 */     super(null);
/*  57 */     this.mReader = reader;
/*  58 */     this.mTraceName = traceName;
/*     */     
/*  60 */     addMenuBar();
/*     */   }
/*     */   
/*     */   public void run() {
/*  64 */     setBlockOnOpen(true);
/*  65 */     open();
/*     */   }
/*     */   
/*     */   protected void configureShell(Shell shell)
/*     */   {
/*  70 */     super.configureShell(shell);
/*  71 */     shell.setText("Traceview: " + this.mTraceName);
/*     */     
/*  73 */     InputStream in = getClass().getClassLoader().getResourceAsStream("icons/traceview-128.png");
/*     */     
/*  75 */     if (in != null) {
/*  76 */       shell.setImage(new Image(shell.getDisplay(), in));
/*     */     }
/*     */     
/*  79 */     shell.setBounds(100, 10, 1282, 900);
/*     */   }
/*     */   
/*     */   protected Control createContents(Composite parent)
/*     */   {
/*  84 */     ColorController.assignMethodColors(parent.getDisplay(), this.mReader.getMethods());
/*  85 */     SelectionController selectionController = new SelectionController();
/*     */     
/*  87 */     GridLayout gridLayout = new GridLayout(1, false);
/*  88 */     gridLayout.marginWidth = 0;
/*  89 */     gridLayout.marginHeight = 0;
/*  90 */     gridLayout.horizontalSpacing = 0;
/*  91 */     gridLayout.verticalSpacing = 0;
/*  92 */     parent.setLayout(gridLayout);
/*     */     
/*  94 */     Display display = parent.getDisplay();
/*  95 */     Color darkGray = display.getSystemColor(16);
/*     */     
/*     */ 
/*     */ 
/*  99 */     SashForm sashForm1 = new SashForm(parent, 512);
/* 100 */     sashForm1.setBackground(darkGray);
/* 101 */     sashForm1.SASH_WIDTH = 3;
/* 102 */     GridData data = new GridData(1808);
/* 103 */     sashForm1.setLayoutData(data);
/*     */     
/*     */ 
/* 106 */     new TimeLineView(sashForm1, this.mReader, selectionController);
/*     */     
/*     */ 
/* 109 */     new ProfileView(sashForm1, this.mReader, selectionController);
/* 110 */     return sashForm1;
/*     */   }
/*     */   
/*     */   protected MenuManager createMenuManager()
/*     */   {
/* 115 */     MenuManager manager = super.createMenuManager();
/*     */     
/* 117 */     MenuManager viewMenu = new MenuManager("View");
/* 118 */     manager.add(viewMenu);
/*     */     
/* 120 */     Action showPropertiesAction = new Action("Show Properties...")
/*     */     {
/*     */       public void run() {
/* 123 */         MainWindow.this.showProperties();
/*     */       }
/* 125 */     };
/* 126 */     viewMenu.add(showPropertiesAction);
/*     */     
/* 128 */     return manager;
/*     */   }
/*     */   
/*     */   private void showProperties() {
/* 132 */     PropertiesDialog dialog = new PropertiesDialog(getShell());
/* 133 */     dialog.setProperties(this.mReader.getProperties());
/* 134 */     dialog.open();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String makeTempTraceFile(String base)
/*     */     throws IOException
/*     */   {
/* 147 */     File temp = File.createTempFile(base, ".trace");
/* 148 */     temp.deleteOnExit();
/*     */     
/* 150 */     FileOutputStream dstStream = null;
/* 151 */     FileInputStream keyStream = null;
/* 152 */     FileInputStream dataStream = null;
/*     */     try
/*     */     {
/* 155 */       dstStream = new FileOutputStream(temp);
/* 156 */       FileChannel dstChannel = dstStream.getChannel();
/*     */       
/*     */ 
/* 159 */       keyStream = new FileInputStream(base + ".key");
/* 160 */       FileChannel srcChannel = keyStream.getChannel();
/* 161 */       long size = dstChannel.transferFrom(srcChannel, 0L, srcChannel.size());
/* 162 */       srcChannel.close();
/*     */       
/*     */ 
/* 165 */       dataStream = new FileInputStream(base + ".data");
/* 166 */       srcChannel = dataStream.getChannel();
/* 167 */       dstChannel.transferFrom(srcChannel, size, srcChannel.size());
/*     */     } finally {
/* 169 */       if (dstStream != null) {
/* 170 */         dstStream.close();
/*     */       }
/* 172 */       if (keyStream != null) {
/* 173 */         keyStream.close();
/*     */       }
/* 175 */       if (dataStream != null) {
/* 176 */         dataStream.close();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 181 */     return temp.getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String getRevision()
/*     */   {
/* 188 */     Properties p = new Properties();
/*     */     try {
/* 190 */       String toolsdir = System.getProperty("com.android.traceview.toolsdir");
/*     */       File sourceProp;
/* 192 */       File sourceProp; if ((toolsdir == null) || (toolsdir.length() == 0)) {
/* 193 */         sourceProp = new File("source.properties");
/*     */       } else {
/* 195 */         sourceProp = new File(toolsdir, "source.properties");
/*     */       }
/*     */       
/* 198 */       FileInputStream fis = null;
/*     */       try {
/* 200 */         fis = new FileInputStream(sourceProp);
/* 201 */         p.load(fis);
/*     */         
/* 203 */         if (fis != null) {
/*     */           try {
/* 205 */             fis.close();
/*     */           }
/*     */           catch (IOException ignore) {}
/*     */         }
/*     */         
/*     */ 
/* 211 */         revision = p.getProperty("Pkg.Revision");
/*     */       }
/*     */       finally
/*     */       {
/* 203 */         if (fis != null) {
/*     */           try {
/* 205 */             fis.close();
/*     */           }
/*     */           catch (IOException ignore) {}
/*     */         }
/*     */       }
/*     */       
/*     */       String revision;
/* 212 */       if ((revision != null) && (revision.length() > 0)) {
/* 213 */         return revision;
/*     */       }
/*     */     }
/*     */     catch (FileNotFoundException e) {}catch (IOException e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 221 */     return null;
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 226 */     TraceReader reader = null;
/* 227 */     boolean regression = false;
/*     */     
/*     */ 
/*     */ 
/* 231 */     String revision = getRevision();
/* 232 */     if (revision != null) {
/* 233 */       new SdkStatsService().ping("Traceview", revision);
/*     */     }
/*     */     
/*     */ 
/* 237 */     int argc = 0;
/* 238 */     int len = args.length;
/* 239 */     while (argc < len) {
/* 240 */       String arg = args[argc];
/* 241 */       if (arg.charAt(0) != '-') {
/*     */         break;
/*     */       }
/* 244 */       if (!arg.equals("-r")) break;
/* 245 */       regression = true;
/*     */       
/*     */ 
/*     */ 
/* 249 */       argc++;
/*     */     }
/* 251 */     if (argc != len - 1) {
/* 252 */       System.out.printf("Usage: java %s [-r] trace%n", new Object[] { MainWindow.class.getName() });
/* 253 */       System.out.printf("  -r   regression only%n", new Object[0]);
/* 254 */       return;
/*     */     }
/*     */     
/* 257 */     String traceName = args[(len - 1)];
/* 258 */     File file = new File(traceName);
/* 259 */     if ((file.exists()) && (file.isDirectory())) {
/* 260 */       System.out.printf("Qemu trace files not supported yet.\n", new Object[0]);
/* 261 */       System.exit(1);
/*     */     }
/*     */     else
/*     */     {
/* 265 */       if (!file.exists())
/*     */       {
/* 267 */         if (new File(traceName + ".trace").exists()) {
/* 268 */           traceName = traceName + ".trace";
/*     */         }
/* 270 */         else if ((new File(traceName + ".data").exists()) && (new File(traceName + ".key").exists()))
/*     */         {
/*     */           try {
/* 273 */             traceName = makeTempTraceFile(traceName);
/*     */           } catch (IOException e) {
/* 275 */             System.err.printf("cannot convert old trace file '%s'\n", new Object[] { traceName });
/* 276 */             System.exit(1);
/*     */           }
/*     */         }
/*     */         else {
/* 280 */           System.err.printf("trace file '%s' not found\n", new Object[] { traceName });
/* 281 */           System.exit(1);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 286 */         reader = new DmTraceReader(traceName, regression);
/*     */       } catch (IOException e) {
/* 288 */         System.err.printf("Failed to read the trace file", new Object[0]);
/* 289 */         e.printStackTrace();
/* 290 */         System.exit(1);
/* 291 */         return;
/*     */       }
/*     */     }
/*     */     
/* 295 */     reader.getTraceUnits().setTimeScale(TraceUnits.TimeScale.MilliSeconds);
/*     */     
/* 297 */     Display.setAppName("Traceview");
/* 298 */     new MainWindow(traceName, reader).run();
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/MainWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
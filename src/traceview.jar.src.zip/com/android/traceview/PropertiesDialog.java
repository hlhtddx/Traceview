/*     */ package com.android.traceview;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jface.dialogs.Dialog;
/*     */ import org.eclipse.jface.dialogs.IDialogConstants;
/*     */ import org.eclipse.jface.viewers.ArrayContentProvider;
/*     */ import org.eclipse.jface.viewers.ColumnLabelProvider;
/*     */ import org.eclipse.jface.viewers.TableViewer;
/*     */ import org.eclipse.jface.viewers.TableViewerColumn;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesDialog
/*     */   extends Dialog
/*     */ {
/*     */   private HashMap<String, String> mProperties;
/*     */   
/*     */   public PropertiesDialog(Shell parent)
/*     */   {
/*  39 */     super(parent);
/*     */     
/*  41 */     setShellStyle(2160);
/*     */   }
/*     */   
/*     */   public void setProperties(HashMap<String, String> properties) {
/*  45 */     this.mProperties = properties;
/*     */   }
/*     */   
/*     */   protected void createButtonsForButtonBar(Composite parent)
/*     */   {
/*  50 */     createButton(parent, 0, IDialogConstants.OK_LABEL, true);
/*     */   }
/*     */   
/*     */   protected Control createDialogArea(Composite parent)
/*     */   {
/*  55 */     Composite container = (Composite)super.createDialogArea(parent);
/*  56 */     GridLayout gridLayout = new GridLayout(1, false);
/*  57 */     gridLayout.marginWidth = 0;
/*  58 */     gridLayout.marginHeight = 0;
/*  59 */     gridLayout.horizontalSpacing = 0;
/*  60 */     gridLayout.verticalSpacing = 0;
/*  61 */     container.setLayout(gridLayout);
/*     */     
/*  63 */     TableViewer tableViewer = new TableViewer(container, 35328);
/*     */     
/*  65 */     tableViewer.getTable().setLinesVisible(true);
/*  66 */     tableViewer.getTable().setHeaderVisible(true);
/*     */     
/*  68 */     TableViewerColumn propertyColumn = new TableViewerColumn(tableViewer, 0);
/*  69 */     propertyColumn.getColumn().setText("Property");
/*  70 */     propertyColumn.setLabelProvider(new ColumnLabelProvider()
/*     */     {
/*     */       public String getText(Object element)
/*     */       {
/*  74 */         Map.Entry<String, String> entry = (Map.Entry)element;
/*  75 */         return (String)entry.getKey();
/*     */       }
/*  77 */     });
/*  78 */     propertyColumn.getColumn().setWidth(400);
/*     */     
/*  80 */     TableViewerColumn valueColumn = new TableViewerColumn(tableViewer, 0);
/*  81 */     valueColumn.getColumn().setText("Value");
/*  82 */     valueColumn.setLabelProvider(new ColumnLabelProvider()
/*     */     {
/*     */       public String getText(Object element)
/*     */       {
/*  86 */         Map.Entry<String, String> entry = (Map.Entry)element;
/*  87 */         return (String)entry.getValue();
/*     */       }
/*  89 */     });
/*  90 */     valueColumn.getColumn().setWidth(200);
/*     */     
/*  92 */     tableViewer.setContentProvider(new ArrayContentProvider());
/*  93 */     tableViewer.setInput(this.mProperties.entrySet().toArray());
/*     */     
/*  95 */     GridData gridData = new GridData();
/*  96 */     gridData.verticalAlignment = 4;
/*  97 */     gridData.horizontalAlignment = 4;
/*  98 */     gridData.grabExcessHorizontalSpace = true;
/*  99 */     gridData.grabExcessVerticalSpace = true;
/* 100 */     tableViewer.getControl().setLayoutData(gridData);
/*     */     
/* 102 */     return container;
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/PropertiesDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
/*     */ package com.android.traceview;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorController
/*     */ {
/*  29 */   private static final int[] systemColors = { 9, 3, 5, 13, 11, 10, 4, 6, 8, 14, 12, 2 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  34 */   private static RGB[] rgbColors = { new RGB(90, 90, 255), new RGB(0, 240, 0), new RGB(255, 0, 0), new RGB(0, 255, 255), new RGB(255, 80, 255), new RGB(200, 200, 0), new RGB(40, 0, 200), new RGB(150, 255, 150), new RGB(150, 0, 0), new RGB(30, 150, 150), new RGB(200, 200, 255), new RGB(0, 120, 0), new RGB(255, 150, 150), new RGB(140, 80, 140), new RGB(150, 100, 50), new RGB(70, 70, 70) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private static HashMap<Integer, Color> colorCache = new HashMap();
/*  53 */   private static HashMap<Integer, Image> imageCache = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   public static Color requestColor(Display display, RGB rgb)
/*     */   {
/*  59 */     return requestColor(display, rgb.red, rgb.green, rgb.blue);
/*     */   }
/*     */   
/*     */   public static Image requestColorSquare(Display display, RGB rgb) {
/*  63 */     return requestColorSquare(display, rgb.red, rgb.green, rgb.blue);
/*     */   }
/*     */   
/*     */   public static Color requestColor(Display display, int red, int green, int blue) {
/*  67 */     int key = red << 16 | green << 8 | blue;
/*  68 */     Color color = (Color)colorCache.get(Integer.valueOf(key));
/*  69 */     if (color == null) {
/*  70 */       color = new Color(display, red, green, blue);
/*  71 */       colorCache.put(Integer.valueOf(key), color);
/*     */     }
/*  73 */     return color;
/*     */   }
/*     */   
/*     */   public static Image requestColorSquare(Display display, int red, int green, int blue) {
/*  77 */     int key = red << 16 | green << 8 | blue;
/*  78 */     Image image = (Image)imageCache.get(Integer.valueOf(key));
/*  79 */     if (image == null) {
/*  80 */       image = new Image(display, 8, 14);
/*  81 */       GC gc = new GC(image);
/*  82 */       Color color = requestColor(display, red, green, blue);
/*  83 */       gc.setBackground(color);
/*  84 */       gc.fillRectangle(image.getBounds());
/*  85 */       gc.dispose();
/*  86 */       imageCache.put(Integer.valueOf(key), image);
/*     */     }
/*  88 */     return image;
/*     */   }
/*     */   
/*     */   public static void assignMethodColors(Display display, MethodData[] methods) {
/*  92 */     int nextColorIndex = 0;
/*  93 */     for (MethodData md : methods) {
/*  94 */       RGB rgb = rgbColors[nextColorIndex];
/*  95 */       nextColorIndex++; if (nextColorIndex == rgbColors.length)
/*  96 */         nextColorIndex = 0;
/*  97 */       Color color = requestColor(display, rgb);
/*  98 */       Image image = requestColorSquare(display, rgb);
/*  99 */       md.setColor(color);
/* 100 */       md.setImage(image);
/*     */       
/*     */ 
/* 103 */       int fadedRed = 150 + rgb.red / 4;
/* 104 */       int fadedGreen = 150 + rgb.green / 4;
/* 105 */       int fadedBlue = 150 + rgb.blue / 4;
/* 106 */       RGB faded = new RGB(fadedRed, fadedGreen, fadedBlue);
/* 107 */       color = requestColor(display, faded);
/* 108 */       image = requestColorSquare(display, faded);
/* 109 */       md.setFadedColor(color);
/* 110 */       md.setFadedImage(image);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ColorController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
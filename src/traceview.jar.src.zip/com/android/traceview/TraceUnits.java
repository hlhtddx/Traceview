/*    */ package com.android.traceview;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TraceUnits
/*    */ {
/* 24 */   private TimeScale mTimeScale = TimeScale.MicroSeconds;
/* 25 */   private double mScale = 1.0D;
/* 26 */   DecimalFormat mFormatter = new DecimalFormat();
/*    */   
/*    */   public double getScaledValue(long value) {
/* 29 */     return value * this.mScale;
/*    */   }
/*    */   
/*    */   public double getScaledValue(double value) {
/* 33 */     return value * this.mScale;
/*    */   }
/*    */   
/*    */   public String valueOf(long value) {
/* 37 */     return valueOf(value);
/*    */   }
/*    */   
/*    */   public String valueOf(double value)
/*    */   {
/* 42 */     double scaled = value * this.mScale;
/* 43 */     String pattern; String pattern; if ((int)scaled == scaled) {
/* 44 */       pattern = "###,###";
/*    */     } else
/* 46 */       pattern = "###,###.###";
/* 47 */     this.mFormatter.applyPattern(pattern);
/* 48 */     return this.mFormatter.format(scaled);
/*    */   }
/*    */   
/*    */   public String labelledString(double value) {
/* 52 */     String units = label();
/* 53 */     String num = valueOf(value);
/* 54 */     return String.format("%s: %s", new Object[] { units, num });
/*    */   }
/*    */   
/*    */   public String labelledString(long value) {
/* 58 */     return labelledString(value);
/*    */   }
/*    */   
/*    */   public String label() {
/* 62 */     if (this.mScale == 1.0D)
/* 63 */       return "usec";
/* 64 */     if (this.mScale == 0.001D)
/* 65 */       return "msec";
/* 66 */     if (this.mScale == 1.0E-6D)
/* 67 */       return "sec";
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   public void setTimeScale(TimeScale val) {
/* 72 */     this.mTimeScale = val;
/* 73 */     switch (val) {
/*    */     case Seconds: 
/* 75 */       this.mScale = 1.0E-6D;
/* 76 */       break;
/*    */     case MilliSeconds: 
/* 78 */       this.mScale = 0.001D;
/* 79 */       break;
/*    */     case MicroSeconds: 
/* 81 */       this.mScale = 1.0D;
/*    */     }
/*    */   }
/*    */   
/*    */   public TimeScale getTimeScale()
/*    */   {
/* 87 */     return this.mTimeScale;
/*    */   }
/*    */   
/*    */   public static enum TimeScale {
/* 91 */     Seconds,  MilliSeconds,  MicroSeconds;
/*    */     
/*    */     private TimeScale() {}
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/TraceUnits.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
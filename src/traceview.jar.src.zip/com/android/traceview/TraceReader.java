/*    */ package com.android.traceview;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TraceReader
/*    */ {
/*    */   private TraceUnits mTraceUnits;
/*    */   
/*    */   public TraceUnits getTraceUnits()
/*    */   {
/* 27 */     if (this.mTraceUnits == null)
/* 28 */       this.mTraceUnits = new TraceUnits();
/* 29 */     return this.mTraceUnits;
/*    */   }
/*    */   
/*    */   public ArrayList<TimeLineView.Record> getThreadTimeRecords() {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public HashMap<Integer, String> getThreadLabels() {
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   public MethodData[] getMethods() {
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   public ThreadData[] getThreads() {
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public long getTotalCpuTime() {
/* 49 */     return 0L;
/*    */   }
/*    */   
/*    */   public long getTotalRealTime() {
/* 53 */     return 0L;
/*    */   }
/*    */   
/*    */   public boolean haveCpuTime() {
/* 57 */     return false;
/*    */   }
/*    */   
/*    */   public boolean haveRealTime() {
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   public HashMap<String, String> getProperties() {
/* 65 */     return null;
/*    */   }
/*    */   
/*    */   public ProfileProvider getProfileProvider() {
/* 69 */     return null;
/*    */   }
/*    */   
/*    */   public TimeBase getPreferredTimeBase() {
/* 73 */     return TimeBase.CPU_TIME;
/*    */   }
/*    */   
/*    */   public String getClockSource() {
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/TraceReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
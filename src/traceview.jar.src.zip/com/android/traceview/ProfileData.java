/*    */ package com.android.traceview;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProfileData
/*    */ {
/*    */   protected MethodData mElement;
/*    */   
/*    */ 
/*    */ 
/*    */   protected MethodData mContext;
/*    */   
/*    */ 
/*    */ 
/*    */   protected boolean mElementIsParent;
/*    */   
/*    */ 
/*    */ 
/*    */   protected long mElapsedInclusiveCpuTime;
/*    */   
/*    */ 
/*    */   protected long mElapsedInclusiveRealTime;
/*    */   
/*    */ 
/*    */   protected int mNumCalls;
/*    */   
/*    */ 
/*    */ 
/*    */   public ProfileData() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public ProfileData(MethodData context, MethodData element, boolean elementIsParent)
/*    */   {
/* 36 */     this.mContext = context;
/* 37 */     this.mElement = element;
/* 38 */     this.mElementIsParent = elementIsParent;
/*    */   }
/*    */   
/*    */   public String getProfileName() {
/* 42 */     return this.mElement.getProfileName();
/*    */   }
/*    */   
/*    */   public MethodData getMethodData() {
/* 46 */     return this.mElement;
/*    */   }
/*    */   
/*    */   public void addElapsedInclusive(long cpuTime, long realTime) {
/* 50 */     this.mElapsedInclusiveCpuTime += cpuTime;
/* 51 */     this.mElapsedInclusiveRealTime += realTime;
/* 52 */     this.mNumCalls += 1;
/*    */   }
/*    */   
/*    */   public void setElapsedInclusive(long cpuTime, long realTime) {
/* 56 */     this.mElapsedInclusiveCpuTime = cpuTime;
/* 57 */     this.mElapsedInclusiveRealTime = realTime;
/*    */   }
/*    */   
/*    */   public long getElapsedInclusiveCpuTime() {
/* 61 */     return this.mElapsedInclusiveCpuTime;
/*    */   }
/*    */   
/*    */   public long getElapsedInclusiveRealTime() {
/* 65 */     return this.mElapsedInclusiveRealTime;
/*    */   }
/*    */   
/*    */ 
/* 69 */   public void setNumCalls(int numCalls) { this.mNumCalls = numCalls; }
/*    */   
/*    */   public String getNumCalls() {
/*    */     int totalCalls;
/*    */     int totalCalls;
/* 74 */     if (this.mElementIsParent) {
/* 75 */       totalCalls = this.mContext.getTotalCalls();
/*    */     } else
/* 77 */       totalCalls = this.mElement.getTotalCalls();
/* 78 */     return String.format("%d/%d", new Object[] { Integer.valueOf(this.mNumCalls), Integer.valueOf(totalCalls) });
/*    */   }
/*    */   
/*    */   public boolean isParent() {
/* 82 */     return this.mElementIsParent;
/*    */   }
/*    */   
/*    */   public MethodData getContext() {
/* 86 */     return this.mContext;
/*    */   }
/*    */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/ProfileData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
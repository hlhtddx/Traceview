/*      */ package com.android.traceview;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import org.eclipse.jface.resource.FontRegistry;
/*      */ import org.eclipse.swt.custom.SashForm;
/*      */ import org.eclipse.swt.events.MouseEvent;
/*      */ import org.eclipse.swt.events.PaintEvent;
/*      */ import org.eclipse.swt.events.PaintListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Cursor;
/*      */ import org.eclipse.swt.graphics.FontData;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.layout.GridData;
/*      */ import org.eclipse.swt.widgets.Canvas;
/*      */ import org.eclipse.swt.widgets.Composite;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ import org.eclipse.swt.widgets.Event;
/*      */ import org.eclipse.swt.widgets.ScrollBar;
/*      */ 
/*      */ public class TimeLineView extends Composite implements java.util.Observer
/*      */ {
/*      */   private HashMap<String, RowData> mRowByName;
/*      */   private RowData[] mRows;
/*      */   private Segment[] mSegments;
/*      */   private HashMap<Integer, String> mThreadLabels;
/*      */   private Timescale mTimescale;
/*      */   private Surface mSurface;
/*      */   private RowLabels mLabels;
/*      */   private SashForm mSashForm;
/*      */   private int mScrollOffsetY;
/*      */   public static final int PixelsPerTick = 50;
/*      */   
/*      */   public static abstract interface Block
/*      */   {
/*      */     public abstract String getName();
/*      */     
/*      */     public abstract MethodData getMethodData();
/*      */     
/*      */     public abstract long getStartTime();
/*      */     
/*      */     public abstract long getEndTime();
/*      */     
/*      */     public abstract Color getColor();
/*      */     
/*      */     public abstract double addWeight(int paramInt1, int paramInt2, double paramDouble);
/*      */     
/*      */     public abstract void clearWeight();
/*      */     
/*      */     public abstract long getExclusiveCpuTime();
/*      */     
/*      */     public abstract long getInclusiveCpuTime();
/*      */     
/*      */     public abstract long getExclusiveRealTime();
/*      */     
/*      */     public abstract long getInclusiveRealTime();
/*      */     
/*      */     public abstract boolean isContextSwitch();
/*      */     
/*      */     public abstract boolean isIgnoredBlock();
/*      */     
/*      */     public abstract Block getParentBlock();
/*      */   }
/*      */   
/*   67 */   private TickScaler mScaleInfo = new TickScaler(0.0D, 0.0D, 0, 50);
/*      */   
/*      */   private static final int LeftMargin = 10;
/*      */   
/*      */   private static final int RightMargin = 60;
/*      */   
/*      */   private Color mColorBlack;
/*      */   
/*      */   private Color mColorGray;
/*      */   
/*      */   private Color mColorDarkGray;
/*      */   
/*      */   private Color mColorForeground;
/*      */   
/*      */   private Color mColorRowBack;
/*      */   
/*      */   private Color mColorZoomSelection;
/*      */   private FontRegistry mFontRegistry;
/*      */   private static final int rowHeight = 20;
/*      */   private static final int rowYMargin = 12;
/*      */   private static final int rowYMarginHalf = 6;
/*      */   private static final int rowYSpace = 32;
/*      */   private static final int majorTickLength = 8;
/*      */   private static final int minorTickLength = 4;
/*      */   private static final int timeLineOffsetY = 58;
/*      */   private static final int tickToFontSpacing = 2;
/*      */   private static final int topMargin = 90;
/*      */   
/*   95 */   private int mMouseRow = -1;
/*      */   
/*      */   private int mNumRows;
/*      */   
/*      */   private int mStartRow;
/*      */   private int mEndRow;
/*      */   private TraceUnits mUnits;
/*      */   private String mClockSource;
/*      */   private boolean mHaveCpuTime;
/*      */   private boolean mHaveRealTime;
/*      */   private int mSmallFontWidth;
/*      */   private int mSmallFontHeight;
/*      */   private SelectionController mSelectionController;
/*      */   private MethodData mHighlightMethodData;
/*      */   private Call mHighlightCall;
/*      */   private static final int MinInclusiveRange = 3;
/*  111 */   private boolean mSetFonts = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static abstract interface Row
/*      */   {
/*      */     public abstract int getId();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract String getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Record
/*      */   {
/*      */     public Record(TimeLineView.Row row, TimeLineView.Block block)
/*      */     {
/*  140 */       this.row = row;
/*  141 */       this.block = block;
/*      */     }
/*      */     
/*      */     TimeLineView.Row row;
/*      */     TimeLineView.Block block; }
/*      */   
/*  147 */   public TimeLineView(Composite parent, TraceReader reader, SelectionController selectionController) { super(parent, 0);
/*  148 */     this.mRowByName = new HashMap();
/*  149 */     this.mSelectionController = selectionController;
/*  150 */     selectionController.addObserver(this);
/*  151 */     this.mUnits = reader.getTraceUnits();
/*  152 */     this.mClockSource = reader.getClockSource();
/*  153 */     this.mHaveCpuTime = reader.haveCpuTime();
/*  154 */     this.mHaveRealTime = reader.haveRealTime();
/*  155 */     this.mThreadLabels = reader.getThreadLabels();
/*      */     
/*  157 */     Display display = getDisplay();
/*  158 */     this.mColorGray = display.getSystemColor(15);
/*  159 */     this.mColorDarkGray = display.getSystemColor(16);
/*  160 */     this.mColorBlack = display.getSystemColor(2);
/*      */     
/*  162 */     this.mColorForeground = display.getSystemColor(2);
/*  163 */     this.mColorRowBack = new Color(display, 240, 240, 255);
/*  164 */     this.mColorZoomSelection = new Color(display, 230, 230, 230);
/*      */     
/*  166 */     this.mFontRegistry = new FontRegistry(display);
/*  167 */     this.mFontRegistry.put("small", new FontData[] { new FontData("Arial", 8, 0) });
/*      */     
/*  169 */     this.mFontRegistry.put("courier8", new FontData[] { new FontData("Courier New", 8, 1) });
/*      */     
/*  171 */     this.mFontRegistry.put("medium", new FontData[] { new FontData("Courier New", 10, 0) });
/*      */     
/*      */ 
/*  174 */     Image image = new Image(display, new org.eclipse.swt.graphics.Rectangle(100, 100, 100, 100));
/*  175 */     GC gc = new GC(image);
/*  176 */     if (this.mSetFonts) {
/*  177 */       gc.setFont(this.mFontRegistry.get("small"));
/*      */     }
/*  179 */     this.mSmallFontWidth = gc.getFontMetrics().getAverageCharWidth();
/*  180 */     this.mSmallFontHeight = gc.getFontMetrics().getHeight();
/*      */     
/*  182 */     image.dispose();
/*  183 */     gc.dispose();
/*      */     
/*  185 */     setLayout(new org.eclipse.swt.layout.FillLayout());
/*      */     
/*      */ 
/*      */ 
/*  189 */     this.mSashForm = new SashForm(this, 256);
/*  190 */     this.mSashForm.setBackground(this.mColorGray);
/*  191 */     this.mSashForm.SASH_WIDTH = 3;
/*      */     
/*      */ 
/*  194 */     Composite composite = new Composite(this.mSashForm, 0);
/*  195 */     org.eclipse.swt.layout.GridLayout layout = new org.eclipse.swt.layout.GridLayout(1, true);
/*  196 */     layout.marginHeight = 0;
/*  197 */     layout.marginWidth = 0;
/*  198 */     layout.verticalSpacing = 1;
/*  199 */     composite.setLayout(layout);
/*      */     
/*      */ 
/*  202 */     BlankCorner corner = new BlankCorner(composite);
/*  203 */     GridData gridData = new GridData(768);
/*  204 */     gridData.heightHint = 90;
/*  205 */     corner.setLayoutData(gridData);
/*      */     
/*      */ 
/*  208 */     this.mLabels = new RowLabels(composite);
/*  209 */     gridData = new GridData(1808);
/*  210 */     this.mLabels.setLayoutData(gridData);
/*      */     
/*      */ 
/*  213 */     composite = new Composite(this.mSashForm, 0);
/*  214 */     layout = new org.eclipse.swt.layout.GridLayout(1, true);
/*  215 */     layout.marginHeight = 0;
/*  216 */     layout.marginWidth = 0;
/*  217 */     layout.verticalSpacing = 1;
/*  218 */     composite.setLayout(layout);
/*      */     
/*  220 */     this.mTimescale = new Timescale(composite);
/*  221 */     gridData = new GridData(768);
/*  222 */     gridData.heightHint = 90;
/*  223 */     this.mTimescale.setLayoutData(gridData);
/*      */     
/*  225 */     this.mSurface = new Surface(composite);
/*  226 */     gridData = new GridData(1808);
/*  227 */     this.mSurface.setLayoutData(gridData);
/*  228 */     this.mSashForm.setWeights(new int[] { 1, 5 });
/*      */     
/*  230 */     final ScrollBar vBar = this.mSurface.getVerticalBar();
/*  231 */     vBar.addListener(13, new org.eclipse.swt.widgets.Listener()
/*      */     {
/*      */       public void handleEvent(Event e) {
/*  234 */         TimeLineView.this.mScrollOffsetY = vBar.getSelection();
/*  235 */         Point dim = TimeLineView.this.mSurface.getSize();
/*  236 */         int newScrollOffsetY = TimeLineView.this.computeVisibleRows(dim.y);
/*  237 */         if (newScrollOffsetY != TimeLineView.this.mScrollOffsetY) {
/*  238 */           TimeLineView.this.mScrollOffsetY = newScrollOffsetY;
/*  239 */           vBar.setSelection(newScrollOffsetY);
/*      */         }
/*  241 */         TimeLineView.this.mLabels.redraw();
/*  242 */         TimeLineView.this.mSurface.redraw();
/*      */       }
/*      */       
/*  245 */     });
/*  246 */     final ScrollBar hBar = this.mSurface.getHorizontalBar();
/*  247 */     hBar.addListener(13, new org.eclipse.swt.widgets.Listener()
/*      */     {
/*      */       public void handleEvent(Event e) {
/*  250 */         TimeLineView.this.mSurface.setScaleFromHorizontalScrollBar(hBar.getSelection());
/*  251 */         TimeLineView.this.mSurface.redraw();
/*      */       }
/*      */       
/*  254 */     });
/*  255 */     this.mSurface.addListener(11, new org.eclipse.swt.widgets.Listener()
/*      */     {
/*      */       public void handleEvent(Event e) {
/*  258 */         Point dim = TimeLineView.this.mSurface.getSize();
/*      */         
/*      */ 
/*  261 */         if (dim.y >= TimeLineView.this.mNumRows * 32) {
/*  262 */           vBar.setVisible(false);
/*      */         } else {
/*  264 */           vBar.setVisible(true);
/*      */         }
/*  266 */         int newScrollOffsetY = TimeLineView.this.computeVisibleRows(dim.y);
/*  267 */         if (newScrollOffsetY != TimeLineView.this.mScrollOffsetY) {
/*  268 */           TimeLineView.this.mScrollOffsetY = newScrollOffsetY;
/*  269 */           vBar.setSelection(newScrollOffsetY);
/*      */         }
/*      */         
/*  272 */         int spaceNeeded = TimeLineView.this.mNumRows * 32;
/*  273 */         vBar.setMaximum(spaceNeeded);
/*  274 */         vBar.setThumb(dim.y);
/*      */         
/*  276 */         TimeLineView.this.mLabels.redraw();
/*  277 */         TimeLineView.this.mSurface.redraw();
/*      */       }
/*      */       
/*  280 */     });
/*  281 */     this.mSurface.addMouseListener(new org.eclipse.swt.events.MouseAdapter()
/*      */     {
/*      */       public void mouseUp(MouseEvent me) {
/*  284 */         TimeLineView.this.mSurface.mouseUp(me);
/*      */       }
/*      */       
/*      */       public void mouseDown(MouseEvent me)
/*      */       {
/*  289 */         TimeLineView.this.mSurface.mouseDown(me);
/*      */       }
/*      */       
/*      */       public void mouseDoubleClick(MouseEvent me)
/*      */       {
/*  294 */         TimeLineView.this.mSurface.mouseDoubleClick(me);
/*      */       }
/*      */       
/*  297 */     });
/*  298 */     this.mSurface.addMouseMoveListener(new org.eclipse.swt.events.MouseMoveListener()
/*      */     {
/*      */       public void mouseMove(MouseEvent me) {
/*  301 */         TimeLineView.this.mSurface.mouseMove(me);
/*      */       }
/*      */       
/*  304 */     });
/*  305 */     this.mSurface.addMouseWheelListener(new org.eclipse.swt.events.MouseWheelListener()
/*      */     {
/*      */       public void mouseScrolled(MouseEvent me) {
/*  308 */         TimeLineView.this.mSurface.mouseScrolled(me);
/*      */       }
/*      */       
/*  311 */     });
/*  312 */     this.mTimescale.addMouseListener(new org.eclipse.swt.events.MouseAdapter()
/*      */     {
/*      */       public void mouseUp(MouseEvent me) {
/*  315 */         TimeLineView.this.mTimescale.mouseUp(me);
/*      */       }
/*      */       
/*      */       public void mouseDown(MouseEvent me)
/*      */       {
/*  320 */         TimeLineView.this.mTimescale.mouseDown(me);
/*      */       }
/*      */       
/*      */       public void mouseDoubleClick(MouseEvent me)
/*      */       {
/*  325 */         TimeLineView.this.mTimescale.mouseDoubleClick(me);
/*      */       }
/*      */       
/*  328 */     });
/*  329 */     this.mTimescale.addMouseMoveListener(new org.eclipse.swt.events.MouseMoveListener()
/*      */     {
/*      */       public void mouseMove(MouseEvent me) {
/*  332 */         TimeLineView.this.mTimescale.mouseMove(me);
/*      */       }
/*      */       
/*  335 */     });
/*  336 */     this.mLabels.addMouseMoveListener(new org.eclipse.swt.events.MouseMoveListener()
/*      */     {
/*      */       public void mouseMove(MouseEvent me) {
/*  339 */         TimeLineView.this.mLabels.mouseMove(me);
/*      */       }
/*      */       
/*  342 */     });
/*  343 */     setData(reader.getThreadTimeRecords());
/*      */   }
/*      */   
/*      */ 
/*      */   public void update(java.util.Observable objservable, Object arg)
/*      */   {
/*  349 */     if (arg == "TimeLineView") {
/*  350 */       return;
/*      */     }
/*  352 */     boolean foundHighlight = false;
/*      */     
/*  354 */     ArrayList<Selection> selections = this.mSelectionController.getSelections();
/*  355 */     for (Selection selection : selections) {
/*  356 */       Selection.Action action = selection.getAction();
/*  357 */       if (action == Selection.Action.Highlight)
/*      */       {
/*  359 */         String name = selection.getName();
/*      */         
/*  361 */         if (name == "MethodData") {
/*  362 */           foundHighlight = true;
/*  363 */           this.mHighlightMethodData = ((MethodData)selection.getValue());
/*      */           
/*      */ 
/*  366 */           this.mHighlightCall = null;
/*  367 */           startHighlighting();
/*  368 */         } else if (name == "Call") {
/*  369 */           foundHighlight = true;
/*  370 */           this.mHighlightCall = ((Call)selection.getValue());
/*      */           
/*  372 */           this.mHighlightMethodData = null;
/*  373 */           startHighlighting();
/*      */         }
/*      */       } }
/*  376 */     if (!foundHighlight)
/*  377 */       this.mSurface.clearHighlights();
/*      */   }
/*      */   
/*      */   public void setData(ArrayList<Record> records) {
/*  381 */     if (records == null) {
/*  382 */       records = new ArrayList();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  398 */     java.util.Collections.sort(records, new java.util.Comparator()
/*      */     {
/*      */       public int compare(TimeLineView.Record r1, TimeLineView.Record r2) {
/*  401 */         long start1 = r1.block.getStartTime();
/*  402 */         long start2 = r2.block.getStartTime();
/*  403 */         if (start1 > start2)
/*  404 */           return 1;
/*  405 */         if (start1 < start2) {
/*  406 */           return -1;
/*      */         }
/*      */         
/*  409 */         long end1 = r1.block.getEndTime();
/*  410 */         long end2 = r2.block.getEndTime();
/*  411 */         if (end1 > end2)
/*  412 */           return -1;
/*  413 */         if (end1 < end2) {
/*  414 */           return 1;
/*      */         }
/*  416 */         return 0;
/*      */       }
/*      */       
/*  419 */     });
/*  420 */     ArrayList<Segment> segmentList = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*  424 */     double minVal = 0.0D;
/*  425 */     if (records.size() > 0) {
/*  426 */       minVal = ((Record)records.get(0)).block.getStartTime();
/*      */     }
/*      */     
/*      */ 
/*  430 */     double maxVal = 0.0D;
/*  431 */     for (Record rec : records) {
/*  432 */       Row row = rec.row;
/*  433 */       Block block = rec.block;
/*  434 */       if (!block.isIgnoredBlock())
/*      */       {
/*      */ 
/*      */ 
/*  438 */         String rowName = row.getName();
/*  439 */         RowData rd = (RowData)this.mRowByName.get(rowName);
/*  440 */         if (rd == null) {
/*  441 */           rd = new RowData(row);
/*  442 */           this.mRowByName.put(rowName, rd);
/*      */         }
/*  444 */         long blockStartTime = block.getStartTime();
/*  445 */         long blockEndTime = block.getEndTime();
/*  446 */         if (blockEndTime > rd.mEndTime) {
/*  447 */           long start = Math.max(blockStartTime, rd.mEndTime);
/*  448 */           RowData.access$1814(rd, blockEndTime - start);
/*  449 */           rd.mEndTime = blockEndTime;
/*      */         }
/*  451 */         if (blockEndTime > maxVal) {
/*  452 */           maxVal = blockEndTime;
/*      */         }
/*      */         
/*      */ 
/*  456 */         Block top = rd.top();
/*  457 */         if (top == null) {
/*  458 */           rd.push(block);
/*      */         }
/*      */         else
/*      */         {
/*  462 */           long topStartTime = top.getStartTime();
/*  463 */           long topEndTime = top.getEndTime();
/*  464 */           if (topEndTime >= blockStartTime)
/*      */           {
/*  466 */             if (topStartTime < blockStartTime) {
/*  467 */               Segment segment = new Segment(rd, top, topStartTime, blockStartTime);
/*      */               
/*  469 */               segmentList.add(segment);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  474 */             if (topEndTime == blockStartTime)
/*  475 */               rd.pop();
/*  476 */             rd.push(block);
/*      */           }
/*      */           else {
/*  479 */             popFrames(rd, top, blockStartTime, segmentList);
/*  480 */             rd.push(block);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  485 */     for (RowData rd : this.mRowByName.values()) {
/*  486 */       Block top = rd.top();
/*  487 */       popFrames(rd, top, 2147483647L, segmentList);
/*      */     }
/*      */     
/*  490 */     this.mSurface.setRange(minVal, maxVal);
/*  491 */     this.mSurface.setLimitRange(minVal, maxVal);
/*      */     
/*      */ 
/*  494 */     java.util.Collection<RowData> rv = this.mRowByName.values();
/*  495 */     this.mRows = ((RowData[])rv.toArray(new RowData[rv.size()]));
/*  496 */     java.util.Arrays.sort(this.mRows, new java.util.Comparator()
/*      */     {
/*      */       public int compare(TimeLineView.RowData rd1, TimeLineView.RowData rd2) {
/*  499 */         return (int)(rd2.mElapsed - rd1.mElapsed);
/*      */       }
/*      */     });
/*      */     
/*      */ 
/*  504 */     for (int ii = 0; ii < this.mRows.length; ii++) {
/*  505 */       this.mRows[ii].mRank = ii;
/*      */     }
/*      */     
/*      */ 
/*  509 */     this.mNumRows = 0;
/*  510 */     for (int ii = 0; ii < this.mRows.length; ii++) {
/*  511 */       if (this.mRows[ii].mElapsed == 0L)
/*      */         break;
/*  513 */       this.mNumRows += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  518 */     this.mSegments = ((Segment[])segmentList.toArray(new Segment[segmentList.size()]));
/*  519 */     java.util.Arrays.sort(this.mSegments, new java.util.Comparator()
/*      */     {
/*      */       public int compare(TimeLineView.Segment bd1, TimeLineView.Segment bd2) {
/*  522 */         TimeLineView.RowData rd1 = bd1.mRowData;
/*  523 */         TimeLineView.RowData rd2 = bd2.mRowData;
/*  524 */         int diff = rd1.mRank - rd2.mRank;
/*  525 */         if (diff == 0) {
/*  526 */           long timeDiff = bd1.mStartTime - bd2.mStartTime;
/*  527 */           if (timeDiff == 0L)
/*  528 */             timeDiff = bd1.mEndTime - bd2.mEndTime;
/*  529 */           return (int)timeDiff;
/*      */         }
/*  531 */         return diff;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void popFrames(RowData rd, Block top, long startTime, ArrayList<Segment> segmentList)
/*      */   {
/*  550 */     long topEndTime = top.getEndTime();
/*  551 */     long lastEndTime = top.getStartTime();
/*  552 */     while (topEndTime <= startTime) {
/*  553 */       if (topEndTime > lastEndTime) {
/*  554 */         Segment segment = new Segment(rd, top, lastEndTime, topEndTime);
/*  555 */         segmentList.add(segment);
/*  556 */         lastEndTime = topEndTime;
/*      */       }
/*  558 */       rd.pop();
/*  559 */       top = rd.top();
/*  560 */       if (top == null)
/*  561 */         return;
/*  562 */       topEndTime = top.getEndTime();
/*      */     }
/*      */     
/*      */ 
/*  566 */     if (lastEndTime < startTime) {
/*  567 */       Segment bd = new Segment(rd, top, lastEndTime, startTime);
/*  568 */       segmentList.add(bd);
/*      */     }
/*      */   }
/*      */   
/*      */   private class RowLabels extends Canvas
/*      */   {
/*      */     private static final int labelMarginX = 2;
/*      */     
/*      */     public RowLabels(Composite parent)
/*      */     {
/*  578 */       super(262144);
/*  579 */       addPaintListener(new PaintListener()
/*      */       {
/*      */         public void paintControl(PaintEvent pe) {
/*  582 */           TimeLineView.RowLabels.this.draw(pe.display, pe.gc);
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */     private void mouseMove(MouseEvent me) {
/*  588 */       int rownum = (me.y + TimeLineView.this.mScrollOffsetY) / 32;
/*  589 */       if (TimeLineView.this.mMouseRow != rownum) {
/*  590 */         TimeLineView.this.mMouseRow = rownum;
/*  591 */         redraw();
/*  592 */         TimeLineView.this.mSurface.redraw();
/*      */       }
/*      */     }
/*      */     
/*      */     private void draw(Display display, GC gc) {
/*  597 */       if (TimeLineView.this.mSegments.length == 0)
/*      */       {
/*      */ 
/*  600 */         return;
/*      */       }
/*  602 */       Point dim = getSize();
/*      */       
/*      */ 
/*  605 */       Image image = new Image(display, getBounds());
/*      */       
/*      */ 
/*  608 */       GC gcImage = new GC(image);
/*  609 */       if (TimeLineView.this.mSetFonts) {
/*  610 */         gcImage.setFont(TimeLineView.this.mFontRegistry.get("medium"));
/*      */       }
/*  612 */       if (TimeLineView.this.mNumRows > 2)
/*      */       {
/*  614 */         gcImage.setBackground(TimeLineView.this.mColorRowBack);
/*  615 */         for (int ii = 1; ii < TimeLineView.this.mNumRows; ii += 2) {
/*  616 */           TimeLineView.RowData rd = TimeLineView.this.mRows[ii];
/*  617 */           int y1 = rd.mRank * 32 - TimeLineView.this.mScrollOffsetY;
/*  618 */           gcImage.fillRectangle(0, y1, dim.x, 32);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  623 */       int offsetY = 6 - TimeLineView.this.mScrollOffsetY;
/*  624 */       for (int ii = TimeLineView.this.mStartRow; ii <= TimeLineView.this.mEndRow; ii++) {
/*  625 */         TimeLineView.RowData rd = TimeLineView.this.mRows[ii];
/*  626 */         int y1 = rd.mRank * 32 + offsetY;
/*  627 */         Point extent = gcImage.stringExtent(rd.mName);
/*  628 */         int x1 = dim.x - extent.x - 2;
/*  629 */         gcImage.drawString(rd.mName, x1, y1, true);
/*      */       }
/*      */       
/*      */ 
/*  633 */       if ((TimeLineView.this.mMouseRow >= TimeLineView.this.mStartRow) && (TimeLineView.this.mMouseRow <= TimeLineView.this.mEndRow)) {
/*  634 */         gcImage.setForeground(TimeLineView.this.mColorGray);
/*  635 */         int y1 = TimeLineView.this.mMouseRow * 32 - TimeLineView.this.mScrollOffsetY;
/*  636 */         gcImage.drawRectangle(0, y1, dim.x, 32);
/*      */       }
/*      */       
/*      */ 
/*  640 */       gc.drawImage(image, 0, 0);
/*      */       
/*      */ 
/*  643 */       image.dispose();
/*  644 */       gcImage.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */   private class BlankCorner extends Canvas
/*      */   {
/*      */     public BlankCorner(Composite parent) {
/*  651 */       super(0);
/*  652 */       addPaintListener(new PaintListener()
/*      */       {
/*      */         public void paintControl(PaintEvent pe) {
/*  655 */           TimeLineView.BlankCorner.this.draw(pe.display, pe.gc);
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */     private void draw(Display display, GC gc)
/*      */     {
/*  662 */       Image image = new Image(display, getBounds());
/*  663 */       gc.drawImage(image, 0, 0);
/*      */       
/*      */ 
/*  666 */       image.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */   private class Timescale extends Canvas {
/*  671 */     private Point mMouse = new Point(10, 0);
/*      */     private Cursor mZoomCursor;
/*  673 */     private String mMethodName = null;
/*  674 */     private Color mMethodColor = null;
/*      */     
/*      */     private String mDetails;
/*      */     
/*      */     private int mMethodStartY;
/*      */     private int mDetailsStartY;
/*      */     private int mMarkStartX;
/*      */     private int mMarkEndX;
/*      */     private static final int METHOD_BLOCK_MARGIN = 10;
/*      */     
/*      */     public Timescale(Composite parent)
/*      */     {
/*  686 */       super(0);
/*  687 */       Display display = getDisplay();
/*  688 */       this.mZoomCursor = new Cursor(display, 9);
/*  689 */       setCursor(this.mZoomCursor);
/*  690 */       this.mMethodStartY = (TimeLineView.this.mSmallFontHeight + 1);
/*  691 */       this.mDetailsStartY = (this.mMethodStartY + TimeLineView.this.mSmallFontHeight + 1);
/*  692 */       addPaintListener(new PaintListener()
/*      */       {
/*      */         public void paintControl(PaintEvent pe) {
/*  695 */           TimeLineView.Timescale.this.draw(pe.display, pe.gc);
/*      */         }
/*      */       });
/*      */     }
/*      */     
/*      */     public void setVbarPosition(int x) {
/*  701 */       this.mMouse.x = x;
/*      */     }
/*      */     
/*      */     public void setMarkStart(int x) {
/*  705 */       this.mMarkStartX = x;
/*      */     }
/*      */     
/*      */     public void setMarkEnd(int x) {
/*  709 */       this.mMarkEndX = x;
/*      */     }
/*      */     
/*      */     public void setMethodName(String name) {
/*  713 */       this.mMethodName = name;
/*      */     }
/*      */     
/*      */     public void setMethodColor(Color color) {
/*  717 */       this.mMethodColor = color;
/*      */     }
/*      */     
/*      */     public void setDetails(String details) {
/*  721 */       this.mDetails = details;
/*      */     }
/*      */     
/*      */     private void mouseMove(MouseEvent me) {
/*  725 */       me.y = -1;
/*  726 */       TimeLineView.this.mSurface.mouseMove(me);
/*      */     }
/*      */     
/*      */     private void mouseDown(MouseEvent me) {
/*  730 */       TimeLineView.this.mSurface.startScaling(me.x);
/*  731 */       TimeLineView.this.mSurface.redraw();
/*      */     }
/*      */     
/*      */     private void mouseUp(MouseEvent me) {
/*  735 */       TimeLineView.this.mSurface.stopScaling(me.x);
/*      */     }
/*      */     
/*      */     private void mouseDoubleClick(MouseEvent me) {
/*  739 */       TimeLineView.this.mSurface.resetScale();
/*  740 */       TimeLineView.this.mSurface.redraw();
/*      */     }
/*      */     
/*      */     private void draw(Display display, GC gc) {
/*  744 */       Point dim = getSize();
/*      */       
/*      */ 
/*  747 */       Image image = new Image(display, getBounds());
/*      */       
/*      */ 
/*  750 */       GC gcImage = new GC(image);
/*  751 */       if (TimeLineView.this.mSetFonts) {
/*  752 */         gcImage.setFont(TimeLineView.this.mFontRegistry.get("medium"));
/*      */       }
/*  754 */       if (TimeLineView.this.mSurface.drawingSelection()) {
/*  755 */         drawSelection(display, gcImage);
/*      */       }
/*      */       
/*  758 */       drawTicks(display, gcImage);
/*      */       
/*      */ 
/*  761 */       gcImage.setForeground(TimeLineView.this.mColorDarkGray);
/*  762 */       gcImage.drawLine(this.mMouse.x, 58, this.mMouse.x, dim.y);
/*      */       
/*      */ 
/*  765 */       drawTickLegend(display, gcImage);
/*      */       
/*      */ 
/*  768 */       drawMethod(display, gcImage);
/*      */       
/*      */ 
/*  771 */       drawDetails(display, gcImage);
/*      */       
/*      */ 
/*  774 */       gc.drawImage(image, 0, 0);
/*      */       
/*      */ 
/*  777 */       image.dispose();
/*  778 */       gcImage.dispose();
/*      */     }
/*      */     
/*      */     private void drawSelection(Display display, GC gc) {
/*  782 */       Point dim = getSize();
/*  783 */       gc.setForeground(TimeLineView.this.mColorGray);
/*  784 */       gc.drawLine(this.mMarkStartX, 58, this.mMarkStartX, dim.y);
/*  785 */       gc.setBackground(TimeLineView.this.mColorZoomSelection);
/*      */       int width;
/*  787 */       int x; int width; if (this.mMarkStartX < this.mMarkEndX) {
/*  788 */         int x = this.mMarkStartX;
/*  789 */         width = this.mMarkEndX - this.mMarkStartX;
/*      */       } else {
/*  791 */         x = this.mMarkEndX;
/*  792 */         width = this.mMarkStartX - this.mMarkEndX;
/*      */       }
/*  794 */       if (width > 1) {
/*  795 */         gc.fillRectangle(x, 58, width, dim.y);
/*      */       }
/*      */     }
/*      */     
/*      */     private void drawTickLegend(Display display, GC gc) {
/*  800 */       int mouseX = this.mMouse.x - 10;
/*  801 */       double mouseXval = TimeLineView.this.mScaleInfo.pixelToValue(mouseX);
/*  802 */       String info = TimeLineView.this.mUnits.labelledString(mouseXval);
/*  803 */       gc.setForeground(TimeLineView.this.mColorForeground);
/*  804 */       gc.drawString(info, 12, 1, true);
/*      */       
/*      */ 
/*  807 */       double maxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/*  808 */       info = TimeLineView.this.mUnits.labelledString(maxVal);
/*  809 */       if (TimeLineView.this.mClockSource != null) {
/*  810 */         info = String.format(" max %s (%s)", new Object[] { info, TimeLineView.this.mClockSource });
/*      */       } else {
/*  812 */         info = String.format(" max %s ", new Object[] { info });
/*      */       }
/*  814 */       Point extent = gc.stringExtent(info);
/*  815 */       Point dim = getSize();
/*  816 */       int x1 = dim.x - 60 - extent.x;
/*  817 */       gc.drawString(info, x1, 1, true);
/*      */     }
/*      */     
/*      */     private void drawMethod(Display display, GC gc) {
/*  821 */       if (this.mMethodName == null) {
/*  822 */         return;
/*      */       }
/*      */       
/*  825 */       int x1 = 10;
/*  826 */       int y1 = this.mMethodStartY;
/*  827 */       gc.setBackground(this.mMethodColor);
/*  828 */       int width = 2 * TimeLineView.this.mSmallFontWidth;
/*  829 */       gc.fillRectangle(x1, y1, width, TimeLineView.this.mSmallFontHeight);
/*  830 */       x1 += width + 10;
/*  831 */       gc.drawString(this.mMethodName, x1, y1, true);
/*      */     }
/*      */     
/*      */     private void drawDetails(Display display, GC gc) {
/*  835 */       if (this.mDetails == null) {
/*  836 */         return;
/*      */       }
/*      */       
/*  839 */       int x1 = 10 + 2 * TimeLineView.this.mSmallFontWidth + 10;
/*  840 */       int y1 = this.mDetailsStartY;
/*  841 */       gc.drawString(this.mDetails, x1, y1, true);
/*      */     }
/*      */     
/*      */     private void drawTicks(Display display, GC gc) {
/*  845 */       Point dim = getSize();
/*  846 */       int y2 = 66;
/*  847 */       int y3 = 62;
/*  848 */       int y4 = y2 + 2;
/*  849 */       gc.setForeground(TimeLineView.this.mColorForeground);
/*  850 */       gc.drawLine(10, 58, dim.x - 60, 58);
/*      */       
/*  852 */       double minVal = TimeLineView.this.mScaleInfo.getMinVal();
/*  853 */       double maxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/*  854 */       double minMajorTick = TimeLineView.this.mScaleInfo.getMinMajorTick();
/*  855 */       double tickIncrement = TimeLineView.this.mScaleInfo.getTickIncrement();
/*  856 */       double minorTickIncrement = tickIncrement / 5.0D;
/*  857 */       double pixelsPerRange = TimeLineView.this.mScaleInfo.getPixelsPerRange();
/*      */       
/*      */ 
/*  860 */       if (minVal < minMajorTick) {
/*  861 */         gc.setForeground(TimeLineView.this.mColorGray);
/*  862 */         double xMinor = minMajorTick;
/*  863 */         for (int ii = 1; ii <= 4; ii++) {
/*  864 */           xMinor -= minorTickIncrement;
/*  865 */           if (xMinor < minVal)
/*      */             break;
/*  867 */           int x1 = 10 + (int)(0.5D + (xMinor - minVal) * pixelsPerRange);
/*      */           
/*  869 */           gc.drawLine(x1, 58, x1, y3);
/*      */         }
/*      */       }
/*      */       
/*  873 */       if (tickIncrement <= 10.0D)
/*      */       {
/*      */ 
/*      */ 
/*  877 */         return;
/*      */       }
/*  879 */       for (double x = minMajorTick; x <= maxVal; x += tickIncrement) {
/*  880 */         int x1 = 10 + (int)(0.5D + (x - minVal) * pixelsPerRange);
/*      */         
/*      */ 
/*      */ 
/*  884 */         gc.setForeground(TimeLineView.this.mColorForeground);
/*  885 */         gc.drawLine(x1, 58, x1, y2);
/*  886 */         if (x > maxVal) {
/*      */           break;
/*      */         }
/*      */         
/*  890 */         String tickString = TimeLineView.this.mUnits.valueOf(x);
/*  891 */         gc.drawString(tickString, x1, y4, true);
/*      */         
/*      */ 
/*  894 */         gc.setForeground(TimeLineView.this.mColorGray);
/*  895 */         double xMinor = x;
/*  896 */         for (int ii = 1; ii <= 4; ii++) {
/*  897 */           xMinor += minorTickIncrement;
/*  898 */           if (xMinor > maxVal)
/*      */             break;
/*  900 */           x1 = 10 + (int)(0.5D + (xMinor - minVal) * pixelsPerRange);
/*      */           
/*  902 */           gc.drawLine(x1, 58, x1, y3);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static enum GraphicsState {
/*  909 */     Normal,  Marking,  Scaling,  Animating,  Scrolling;
/*      */     
/*      */     private GraphicsState() {} }
/*      */   
/*      */   private class Surface extends Canvas { private static final int TotalXMargin = 70;
/*      */     
/*  915 */     public Surface(Composite parent) { super(262912);
/*  916 */       Display display = getDisplay();
/*  917 */       this.mNormalCursor = new Cursor(display, 2);
/*  918 */       this.mIncreasingCursor = new Cursor(display, 12);
/*  919 */       this.mDecreasingCursor = new Cursor(display, 13);
/*      */       
/*  921 */       initZoomFractionsWithExp();
/*      */       
/*  923 */       addPaintListener(new PaintListener()
/*      */       {
/*      */         public void paintControl(PaintEvent pe) {
/*  926 */           TimeLineView.Surface.this.draw(pe.display, pe.gc);
/*      */         }
/*      */         
/*  929 */       });
/*  930 */       this.mZoomAnimator = new Runnable()
/*      */       {
/*      */         public void run() {
/*  933 */           TimeLineView.Surface.this.animateZoom();
/*      */         }
/*      */         
/*  936 */       };
/*  937 */       this.mHighlightAnimator = new Runnable()
/*      */       {
/*      */         public void run() {
/*  940 */           TimeLineView.Surface.this.animateHighlight();
/*      */         }
/*      */       };
/*      */     }
/*      */     
/*      */     private void initZoomFractionsWithExp() {
/*  946 */       this.mZoomFractions = new double[8];
/*  947 */       int next = 0;
/*  948 */       for (int ii = 0; ii < 4; next++) {
/*  949 */         this.mZoomFractions[next] = ((1 << ii) / 16.0D);ii++;
/*      */       }
/*      */       
/*      */ 
/*  953 */       for (int ii = 2; ii < 6; next++) {
/*  954 */         this.mZoomFractions[next] = (((1 << ii) - 1) / (1 << ii));ii++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private void initZoomFractionsWithSinWave()
/*      */     {
/*  962 */       this.mZoomFractions = new double[8];
/*  963 */       for (int ii = 0; ii < 8; ii++) {
/*  964 */         double offset = 3.141592653589793D * ii / 8.0D;
/*  965 */         this.mZoomFractions[ii] = ((Math.sin(4.71238898038469D + offset) + 1.0D) / 2.0D);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setRange(double minVal, double maxVal)
/*      */     {
/*  971 */       this.mMinDataVal = minVal;
/*  972 */       this.mMaxDataVal = maxVal;
/*  973 */       TimeLineView.this.mScaleInfo.setMinVal(minVal);
/*  974 */       TimeLineView.this.mScaleInfo.setMaxVal(maxVal);
/*      */     }
/*      */     
/*      */     public void setLimitRange(double minVal, double maxVal) {
/*  978 */       this.mLimitMinVal = minVal;
/*  979 */       this.mLimitMaxVal = maxVal;
/*      */     }
/*      */     
/*      */     public void resetScale() {
/*  983 */       TimeLineView.this.mScaleInfo.setMinVal(this.mLimitMinVal);
/*  984 */       TimeLineView.this.mScaleInfo.setMaxVal(this.mLimitMaxVal);
/*      */     }
/*      */     
/*      */     public void setScaleFromHorizontalScrollBar(int selection) {
/*  988 */       double minVal = TimeLineView.this.mScaleInfo.getMinVal();
/*  989 */       double maxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/*  990 */       double visibleRange = maxVal - minVal;
/*      */       
/*  992 */       minVal = this.mLimitMinVal + selection;
/*  993 */       maxVal = minVal + visibleRange;
/*  994 */       if (maxVal > this.mLimitMaxVal) {
/*  995 */         maxVal = this.mLimitMaxVal;
/*  996 */         minVal = maxVal - visibleRange;
/*      */       }
/*  998 */       TimeLineView.this.mScaleInfo.setMinVal(minVal);
/*  999 */       TimeLineView.this.mScaleInfo.setMaxVal(maxVal);
/*      */       
/* 1001 */       this.mGraphicsState = TimeLineView.GraphicsState.Scrolling;
/*      */     }
/*      */     
/*      */     private void updateHorizontalScrollBar() {
/* 1005 */       double minVal = TimeLineView.this.mScaleInfo.getMinVal();
/* 1006 */       double maxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/* 1007 */       double visibleRange = maxVal - minVal;
/* 1008 */       double fullRange = this.mLimitMaxVal - this.mLimitMinVal;
/*      */       
/* 1010 */       ScrollBar hBar = getHorizontalBar();
/* 1011 */       if (fullRange > visibleRange) {
/* 1012 */         hBar.setVisible(true);
/* 1013 */         hBar.setMinimum(0);
/* 1014 */         hBar.setMaximum((int)Math.ceil(fullRange));
/* 1015 */         hBar.setThumb((int)Math.ceil(visibleRange));
/* 1016 */         hBar.setSelection((int)Math.floor(minVal - this.mLimitMinVal));
/*      */       } else {
/* 1018 */         hBar.setVisible(false);
/*      */       }
/*      */     }
/*      */     
/*      */     private void draw(Display display, GC gc) {
/* 1023 */       if (TimeLineView.this.mSegments.length == 0)
/*      */       {
/*      */ 
/* 1026 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1030 */       Image image = new Image(display, getBounds());
/*      */       
/*      */ 
/* 1033 */       GC gcImage = new GC(image);
/* 1034 */       if (TimeLineView.this.mSetFonts) {
/* 1035 */         gcImage.setFont(TimeLineView.this.mFontRegistry.get("small"));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1041 */       if (this.mGraphicsState == TimeLineView.GraphicsState.Scaling) {
/* 1042 */         double diff = this.mMouse.x - this.mMouseMarkStartX;
/* 1043 */         if (diff > 0.0D) {
/* 1044 */           double newMinVal = this.mScaleMinVal - diff / this.mScalePixelsPerRange;
/* 1045 */           if (newMinVal < this.mLimitMinVal)
/* 1046 */             newMinVal = this.mLimitMinVal;
/* 1047 */           TimeLineView.this.mScaleInfo.setMinVal(newMinVal);
/*      */ 
/*      */         }
/* 1050 */         else if (diff < 0.0D) {
/* 1051 */           double newMaxVal = this.mScaleMaxVal - diff / this.mScalePixelsPerRange;
/* 1052 */           if (newMaxVal > this.mLimitMaxVal)
/* 1053 */             newMaxVal = this.mLimitMaxVal;
/* 1054 */           TimeLineView.this.mScaleInfo.setMaxVal(newMaxVal);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1062 */       Point dim = getSize();
/* 1063 */       if ((TimeLineView.this.mStartRow != this.mCachedStartRow) || (TimeLineView.this.mEndRow != this.mCachedEndRow) || (TimeLineView.this.mScaleInfo.getMinVal() != this.mCachedMinVal) || (TimeLineView.this.mScaleInfo.getMaxVal() != this.mCachedMaxVal))
/*      */       {
/*      */ 
/* 1066 */         this.mCachedStartRow = TimeLineView.this.mStartRow;
/* 1067 */         this.mCachedEndRow = TimeLineView.this.mEndRow;
/* 1068 */         int xdim = dim.x - 70;
/* 1069 */         TimeLineView.this.mScaleInfo.setNumPixels(xdim);
/* 1070 */         boolean forceEndPoints = (this.mGraphicsState == TimeLineView.GraphicsState.Scaling) || (this.mGraphicsState == TimeLineView.GraphicsState.Animating) || (this.mGraphicsState == TimeLineView.GraphicsState.Scrolling);
/*      */         
/*      */ 
/* 1073 */         TimeLineView.this.mScaleInfo.computeTicks(forceEndPoints);
/* 1074 */         this.mCachedMinVal = TimeLineView.this.mScaleInfo.getMinVal();
/* 1075 */         this.mCachedMaxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/* 1076 */         if (this.mLimitMinVal > TimeLineView.this.mScaleInfo.getMinVal())
/* 1077 */           this.mLimitMinVal = TimeLineView.this.mScaleInfo.getMinVal();
/* 1078 */         if (this.mLimitMaxVal < TimeLineView.this.mScaleInfo.getMaxVal()) {
/* 1079 */           this.mLimitMaxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/*      */         }
/*      */         
/* 1082 */         computeStrips();
/*      */         
/*      */ 
/* 1085 */         updateHorizontalScrollBar();
/*      */       }
/*      */       
/* 1088 */       if (TimeLineView.this.mNumRows > 2)
/*      */       {
/* 1090 */         gcImage.setBackground(TimeLineView.this.mColorRowBack);
/* 1091 */         for (int ii = 1; ii < TimeLineView.this.mNumRows; ii += 2) {
/* 1092 */           TimeLineView.RowData rd = TimeLineView.this.mRows[ii];
/* 1093 */           int y1 = rd.mRank * 32 - TimeLineView.this.mScrollOffsetY;
/* 1094 */           gcImage.fillRectangle(0, y1, dim.x, 32);
/*      */         }
/*      */       }
/*      */       
/* 1098 */       if (drawingSelection()) {
/* 1099 */         drawSelection(display, gcImage);
/*      */       }
/*      */       
/* 1102 */       String blockName = null;
/* 1103 */       Color blockColor = null;
/* 1104 */       String blockDetails = null;
/*      */       
/* 1106 */       if (this.mDebug) {
/* 1107 */         double pixelsPerRange = TimeLineView.this.mScaleInfo.getPixelsPerRange();
/* 1108 */         System.out.printf("dim.x %d pixels %d minVal %f, maxVal %f ppr %f rpp %f\n", new Object[] { Integer.valueOf(dim.x), Integer.valueOf(dim.x - 70), Double.valueOf(TimeLineView.this.mScaleInfo.getMinVal()), Double.valueOf(TimeLineView.this.mScaleInfo.getMaxVal()), Double.valueOf(pixelsPerRange), Double.valueOf(1.0D / pixelsPerRange) });
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1117 */       TimeLineView.Block selectBlock = null;
/* 1118 */       for (TimeLineView.Strip strip : this.mStripList) {
/* 1119 */         if (strip.mColor != null)
/*      */         {
/*      */ 
/*      */ 
/* 1123 */           gcImage.setBackground(strip.mColor);
/* 1124 */           gcImage.fillRectangle(strip.mX, strip.mY - TimeLineView.this.mScrollOffsetY, strip.mWidth, strip.mHeight);
/*      */           
/* 1126 */           if (TimeLineView.this.mMouseRow == strip.mRowData.mRank) {
/* 1127 */             if ((this.mMouse.x >= strip.mX) && (this.mMouse.x < strip.mX + strip.mWidth))
/*      */             {
/* 1129 */               TimeLineView.Block block = strip.mSegment.mBlock;
/* 1130 */               blockName = block.getName();
/* 1131 */               blockColor = strip.mColor;
/* 1132 */               if (TimeLineView.this.mHaveCpuTime) {
/* 1133 */                 if (TimeLineView.this.mHaveRealTime) {
/* 1134 */                   blockDetails = String.format("excl cpu %s, incl cpu %s, excl real %s, incl real %s", new Object[] { TimeLineView.this.mUnits.labelledString(block.getExclusiveCpuTime()), TimeLineView.this.mUnits.labelledString(block.getInclusiveCpuTime()), TimeLineView.this.mUnits.labelledString(block.getExclusiveRealTime()), TimeLineView.this.mUnits.labelledString(block.getInclusiveRealTime()) });
/*      */ 
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/*      */ 
/*      */ 
/* 1142 */                   blockDetails = String.format("excl cpu %s, incl cpu %s", new Object[] { TimeLineView.this.mUnits.labelledString(block.getExclusiveCpuTime()), TimeLineView.this.mUnits.labelledString(block.getInclusiveCpuTime()) });
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/*      */               else {
/* 1148 */                 blockDetails = String.format("excl real %s, incl real %s", new Object[] { TimeLineView.this.mUnits.labelledString(block.getExclusiveRealTime()), TimeLineView.this.mUnits.labelledString(block.getInclusiveRealTime()) });
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1154 */             if ((this.mMouseSelect.x >= strip.mX) && (this.mMouseSelect.x < strip.mX + strip.mWidth))
/*      */             {
/* 1156 */               selectBlock = strip.mSegment.mBlock; }
/*      */           }
/*      */         }
/*      */       }
/* 1160 */       this.mMouseSelect.x = 0;
/* 1161 */       this.mMouseSelect.y = 0;
/*      */       
/* 1163 */       if (selectBlock != null) {
/* 1164 */         ArrayList<Selection> selections = new ArrayList();
/*      */         
/* 1166 */         TimeLineView.RowData rd = TimeLineView.this.mRows[TimeLineView.this.mMouseRow];
/* 1167 */         selections.add(Selection.highlight("Thread", rd.mName));
/* 1168 */         selections.add(Selection.highlight("Call", selectBlock));
/*      */         
/* 1170 */         int mouseX = this.mMouse.x - 10;
/* 1171 */         double mouseXval = TimeLineView.this.mScaleInfo.pixelToValue(mouseX);
/* 1172 */         selections.add(Selection.highlight("Time", Double.valueOf(mouseXval)));
/*      */         
/* 1174 */         TimeLineView.this.mSelectionController.change(selections, "TimeLineView");
/* 1175 */         TimeLineView.this.mHighlightMethodData = null;
/* 1176 */         TimeLineView.this.mHighlightCall = ((Call)selectBlock);
/* 1177 */         TimeLineView.this.startHighlighting();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1185 */       if ((TimeLineView.this.mMouseRow >= 0) && (TimeLineView.this.mMouseRow < TimeLineView.this.mNumRows) && (this.mHighlightStep == 0)) {
/* 1186 */         gcImage.setForeground(TimeLineView.this.mColorGray);
/* 1187 */         int y1 = TimeLineView.this.mMouseRow * 32 - TimeLineView.this.mScrollOffsetY;
/* 1188 */         gcImage.drawLine(0, y1, dim.x, y1);
/* 1189 */         gcImage.drawLine(0, y1 + 32, dim.x, y1 + 32);
/*      */       }
/*      */       
/*      */ 
/* 1193 */       drawHighlights(gcImage, dim);
/*      */       
/*      */ 
/* 1196 */       gcImage.setForeground(TimeLineView.this.mColorDarkGray);
/* 1197 */       int lineEnd = Math.min(dim.y, TimeLineView.this.mNumRows * 32);
/* 1198 */       gcImage.drawLine(this.mMouse.x, 0, this.mMouse.x, lineEnd);
/*      */       
/* 1200 */       if (blockName != null) {
/* 1201 */         TimeLineView.this.mTimescale.setMethodName(blockName);
/* 1202 */         TimeLineView.this.mTimescale.setMethodColor(blockColor);
/* 1203 */         TimeLineView.this.mTimescale.setDetails(blockDetails);
/* 1204 */         this.mShowHighlightName = false;
/* 1205 */       } else if (this.mShowHighlightName)
/*      */       {
/* 1207 */         MethodData md = TimeLineView.this.mHighlightMethodData;
/* 1208 */         if ((md == null) && (TimeLineView.this.mHighlightCall != null))
/* 1209 */           md = TimeLineView.this.mHighlightCall.getMethodData();
/* 1210 */         if (md == null)
/* 1211 */           System.out.printf("null highlight?\n", new Object[0]);
/* 1212 */         if (md != null) {
/* 1213 */           TimeLineView.this.mTimescale.setMethodName(md.getProfileName());
/* 1214 */           TimeLineView.this.mTimescale.setMethodColor(md.getColor());
/* 1215 */           TimeLineView.this.mTimescale.setDetails(null);
/*      */         }
/*      */       } else {
/* 1218 */         TimeLineView.this.mTimescale.setMethodName(null);
/* 1219 */         TimeLineView.this.mTimescale.setMethodColor(null);
/* 1220 */         TimeLineView.this.mTimescale.setDetails(null);
/*      */       }
/* 1222 */       TimeLineView.this.mTimescale.redraw();
/*      */       
/*      */ 
/* 1225 */       gc.drawImage(image, 0, 0);
/*      */       
/*      */ 
/* 1228 */       image.dispose();
/* 1229 */       gcImage.dispose();
/*      */     }
/*      */     
/*      */     private void drawHighlights(GC gc, Point dim) {
/* 1233 */       int height = this.mHighlightHeight;
/* 1234 */       if (height <= 0)
/* 1235 */         return;
/* 1236 */       for (TimeLineView.Range range : this.mHighlightExclusive) {
/* 1237 */         gc.setBackground(range.mColor);
/* 1238 */         int xStart = range.mXdim.x;
/* 1239 */         int width = range.mXdim.y;
/* 1240 */         gc.fillRectangle(xStart, range.mY - height - TimeLineView.this.mScrollOffsetY, width, height);
/*      */       }
/*      */       
/*      */ 
/* 1244 */       height--;
/* 1245 */       if (height <= 0) {
/* 1246 */         height = 1;
/*      */       }
/*      */       
/* 1249 */       gc.setForeground(TimeLineView.this.mColorDarkGray);
/* 1250 */       gc.setBackground(TimeLineView.this.mColorDarkGray);
/* 1251 */       for (TimeLineView.Range range : this.mHighlightInclusive) {
/* 1252 */         int x1 = range.mXdim.x;
/* 1253 */         int x2 = range.mXdim.y;
/* 1254 */         boolean drawLeftEnd = false;
/* 1255 */         boolean drawRightEnd = false;
/* 1256 */         if (x1 >= 10) {
/* 1257 */           drawLeftEnd = true;
/*      */         } else
/* 1259 */           x1 = 10;
/* 1260 */         if (x2 >= 10) {
/* 1261 */           drawRightEnd = true;
/*      */         } else
/* 1263 */           x2 = dim.x - 60;
/* 1264 */         int y1 = range.mY + 20 + 2 - TimeLineView.this.mScrollOffsetY;
/*      */         
/*      */ 
/*      */ 
/* 1268 */         if (x2 - x1 < 3) {
/* 1269 */           int width = x2 - x1;
/* 1270 */           if (width < 2)
/* 1271 */             width = 2;
/* 1272 */           gc.fillRectangle(x1, y1, width, height);
/*      */         }
/*      */         else {
/* 1275 */           if (drawLeftEnd) {
/* 1276 */             if (drawRightEnd)
/*      */             {
/* 1278 */               int[] points = { x1, y1, x1, y1 + height, x2, y1 + height, x2, y1 };
/*      */               
/* 1280 */               gc.drawPolyline(points);
/*      */             }
/*      */             else {
/* 1283 */               int[] points = { x1, y1, x1, y1 + height, x2, y1 + height };
/*      */               
/* 1285 */               gc.drawPolyline(points);
/*      */             }
/*      */           }
/* 1288 */           else if (drawRightEnd)
/*      */           {
/* 1290 */             int[] points = { x1, y1 + height, x2, y1 + height, x2, y1 };
/*      */             
/* 1292 */             gc.drawPolyline(points);
/*      */           }
/*      */           else {
/* 1295 */             int[] points = { x1, y1 + height, x2, y1 + height };
/* 1296 */             gc.drawPolyline(points);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1301 */           if (!drawLeftEnd) {
/* 1302 */             int[] points = { x1 + 7, y1 + height - 4, x1, y1 + height, x1 + 7, y1 + height + 4 };
/*      */             
/* 1304 */             gc.fillPolygon(points);
/*      */           }
/* 1306 */           if (!drawRightEnd) {
/* 1307 */             int[] points = { x2 - 7, y1 + height - 4, x2, y1 + height, x2 - 7, y1 + height + 4 };
/*      */             
/* 1309 */             gc.fillPolygon(points);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1315 */     private boolean drawingSelection() { return (this.mGraphicsState == TimeLineView.GraphicsState.Marking) || (this.mGraphicsState == TimeLineView.GraphicsState.Animating); }
/*      */     
/*      */ 
/*      */     private void drawSelection(Display display, GC gc)
/*      */     {
/* 1320 */       Point dim = getSize();
/* 1321 */       gc.setForeground(TimeLineView.this.mColorGray);
/* 1322 */       gc.drawLine(this.mMouseMarkStartX, 0, this.mMouseMarkStartX, dim.y);
/* 1323 */       gc.setBackground(TimeLineView.this.mColorZoomSelection);
/*      */       
/* 1325 */       int mouseX = this.mGraphicsState == TimeLineView.GraphicsState.Animating ? this.mMouseMarkEndX : this.mMouse.x;
/*      */       int width;
/* 1327 */       int x; int width; if (this.mMouseMarkStartX < mouseX) {
/* 1328 */         int x = this.mMouseMarkStartX;
/* 1329 */         width = mouseX - this.mMouseMarkStartX;
/*      */       } else {
/* 1331 */         x = mouseX;
/* 1332 */         width = this.mMouseMarkStartX - mouseX;
/*      */       }
/* 1334 */       gc.fillRectangle(x, 0, width, dim.y);
/*      */     }
/*      */     
/*      */     private void computeStrips() {
/* 1338 */       double minVal = TimeLineView.this.mScaleInfo.getMinVal();
/* 1339 */       double maxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/*      */       
/*      */ 
/* 1342 */       TimeLineView.Pixel[] pixels = new TimeLineView.Pixel[TimeLineView.this.mNumRows];
/* 1343 */       for (int ii = 0; ii < TimeLineView.this.mNumRows; ii++) {
/* 1344 */         pixels[ii] = new TimeLineView.Pixel(null);
/*      */       }
/*      */       
/* 1347 */       for (int ii = 0; ii < TimeLineView.this.mSegments.length; ii++) {
/* 1348 */         TimeLineView.access$2500(TimeLineView.this)[ii].mBlock.clearWeight();
/*      */       }
/*      */       
/* 1351 */       this.mStripList.clear();
/* 1352 */       this.mHighlightExclusive.clear();
/* 1353 */       this.mHighlightInclusive.clear();
/* 1354 */       MethodData callMethod = null;
/* 1355 */       long callStart = 0L;
/* 1356 */       long callEnd = -1L;
/* 1357 */       TimeLineView.RowData callRowData = null;
/* 1358 */       int prevMethodStart = -1;
/* 1359 */       int prevMethodEnd = -1;
/* 1360 */       int prevCallStart = -1;
/* 1361 */       int prevCallEnd = -1;
/* 1362 */       if (TimeLineView.this.mHighlightCall != null) {
/* 1363 */         int callPixelStart = -1;
/* 1364 */         int callPixelEnd = -1;
/* 1365 */         callStart = TimeLineView.this.mHighlightCall.getStartTime();
/* 1366 */         callEnd = TimeLineView.this.mHighlightCall.getEndTime();
/* 1367 */         callMethod = TimeLineView.this.mHighlightCall.getMethodData();
/* 1368 */         if (callStart >= minVal)
/* 1369 */           callPixelStart = TimeLineView.this.mScaleInfo.valueToPixel(callStart);
/* 1370 */         if (callEnd <= maxVal) {
/* 1371 */           callPixelEnd = TimeLineView.this.mScaleInfo.valueToPixel(callEnd);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1376 */         int threadId = TimeLineView.this.mHighlightCall.getThreadId();
/* 1377 */         String threadName = (String)TimeLineView.this.mThreadLabels.get(Integer.valueOf(threadId));
/* 1378 */         callRowData = (TimeLineView.RowData)TimeLineView.this.mRowByName.get(threadName);
/* 1379 */         int y1 = callRowData.mRank * 32 + 6;
/* 1380 */         Color color = callMethod.getColor();
/* 1381 */         this.mHighlightInclusive.add(new TimeLineView.Range(callPixelStart + 10, callPixelEnd + 10, y1, color));
/*      */       }
/*      */       
/* 1384 */       for (TimeLineView.Segment segment : TimeLineView.this.mSegments)
/* 1385 */         if (segment.mEndTime > minVal)
/*      */         {
/* 1387 */           if (segment.mStartTime < maxVal)
/*      */           {
/*      */ 
/* 1390 */             TimeLineView.Block block = segment.mBlock;
/*      */             
/*      */ 
/*      */ 
/* 1394 */             Color color = block.getColor();
/* 1395 */             if (color != null)
/*      */             {
/*      */ 
/* 1398 */               double recordStart = Math.max(segment.mStartTime, minVal);
/* 1399 */               double recordEnd = Math.min(segment.mEndTime, maxVal);
/* 1400 */               if (recordStart != recordEnd)
/*      */               {
/* 1402 */                 int pixelStart = TimeLineView.this.mScaleInfo.valueToPixel(recordStart);
/* 1403 */                 int pixelEnd = TimeLineView.this.mScaleInfo.valueToPixel(recordEnd);
/* 1404 */                 int width = pixelEnd - pixelStart;
/* 1405 */                 boolean isContextSwitch = segment.mIsContextSwitch;
/*      */                 
/* 1407 */                 TimeLineView.RowData rd = segment.mRowData;
/* 1408 */                 MethodData md = block.getMethodData();
/*      */                 
/*      */ 
/* 1411 */                 int y1 = rd.mRank * 32 + 6;
/*      */                 
/*      */ 
/* 1414 */                 if (rd.mRank > TimeLineView.this.mEndRow) {
/*      */                   break;
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1428 */                 if (TimeLineView.this.mHighlightMethodData != null) {
/* 1429 */                   if (TimeLineView.this.mHighlightMethodData == md) {
/* 1430 */                     if ((prevMethodStart != pixelStart) || (prevMethodEnd != pixelEnd)) {
/* 1431 */                       prevMethodStart = pixelStart;
/* 1432 */                       prevMethodEnd = pixelEnd;
/* 1433 */                       int rangeWidth = width;
/* 1434 */                       if (rangeWidth == 0)
/* 1435 */                         rangeWidth = 1;
/* 1436 */                       this.mHighlightExclusive.add(new TimeLineView.Range(pixelStart + 10, rangeWidth, y1, color));
/*      */                       
/* 1438 */                       callStart = block.getStartTime();
/* 1439 */                       int callPixelStart = -1;
/* 1440 */                       if (callStart >= minVal)
/* 1441 */                         callPixelStart = TimeLineView.this.mScaleInfo.valueToPixel(callStart);
/* 1442 */                       int callPixelEnd = -1;
/* 1443 */                       callEnd = block.getEndTime();
/* 1444 */                       if (callEnd <= maxVal)
/* 1445 */                         callPixelEnd = TimeLineView.this.mScaleInfo.valueToPixel(callEnd);
/* 1446 */                       if ((prevCallStart != callPixelStart) || (prevCallEnd != callPixelEnd)) {
/* 1447 */                         prevCallStart = callPixelStart;
/* 1448 */                         prevCallEnd = callPixelEnd;
/* 1449 */                         this.mHighlightInclusive.add(new TimeLineView.Range(callPixelStart + 10, callPixelEnd + 10, y1, color));
/*      */                       }
/*      */                       
/*      */                     }
/*      */                   }
/* 1454 */                   else if (this.mFadeColors) {
/* 1455 */                     color = md.getFadedColor();
/*      */                   }
/* 1457 */                 } else if (TimeLineView.this.mHighlightCall != null) {
/* 1458 */                   if ((segment.mStartTime >= callStart) && (segment.mEndTime <= callEnd) && (callMethod == md) && (callRowData == rd))
/*      */                   {
/*      */ 
/* 1461 */                     if ((prevMethodStart != pixelStart) || (prevMethodEnd != pixelEnd)) {
/* 1462 */                       prevMethodStart = pixelStart;
/* 1463 */                       prevMethodEnd = pixelEnd;
/* 1464 */                       int rangeWidth = width;
/* 1465 */                       if (rangeWidth == 0)
/* 1466 */                         rangeWidth = 1;
/* 1467 */                       this.mHighlightExclusive.add(new TimeLineView.Range(pixelStart + 10, rangeWidth, y1, color));
/*      */                     }
/*      */                   }
/* 1470 */                   else if (this.mFadeColors) {
/* 1471 */                     color = md.getFadedColor();
/*      */                   }
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1495 */                 TimeLineView.Pixel pix = pixels[rd.mRank];
/* 1496 */                 if (pix.mStart != pixelStart) {
/* 1497 */                   if (pix.mSegment != null)
/*      */                   {
/* 1499 */                     emitPixelStrip(rd, y1, pix);
/*      */                   }
/*      */                   
/* 1502 */                   if (width == 0)
/*      */                   {
/*      */ 
/*      */ 
/*      */ 
/* 1507 */                     double weight = computeWeight(recordStart, recordEnd, isContextSwitch, pixelStart);
/*      */                     
/* 1509 */                     weight = block.addWeight(pixelStart, rd.mRank, weight);
/* 1510 */                     if (weight > pix.mMaxWeight) {
/* 1511 */                       pix.setFields(pixelStart, weight, segment, color, rd);
/*      */                     }
/*      */                   }
/*      */                   else {
/* 1515 */                     int x1 = pixelStart + 10;
/* 1516 */                     TimeLineView.Strip strip = new TimeLineView.Strip(x1, isContextSwitch ? y1 + 20 - 1 : y1, width, isContextSwitch ? 1 : 20, rd, segment, color);
/*      */                     
/*      */ 
/*      */ 
/* 1520 */                     this.mStripList.add(strip);
/*      */                   }
/*      */                 } else {
/* 1523 */                   double weight = computeWeight(recordStart, recordEnd, isContextSwitch, pixelStart);
/*      */                   
/* 1525 */                   weight = block.addWeight(pixelStart, rd.mRank, weight);
/* 1526 */                   if (weight > pix.mMaxWeight) {
/* 1527 */                     pix.setFields(pixelStart, weight, segment, color, rd);
/*      */                   }
/* 1529 */                   if (width == 1)
/*      */                   {
/* 1531 */                     emitPixelStrip(rd, y1, pix);
/*      */                     
/*      */ 
/* 1534 */                     pixelStart++;
/* 1535 */                     weight = computeWeight(recordStart, recordEnd, isContextSwitch, pixelStart);
/*      */                     
/* 1537 */                     weight = block.addWeight(pixelStart, rd.mRank, weight);
/* 1538 */                     pix.setFields(pixelStart, weight, segment, color, rd);
/* 1539 */                   } else if (width > 1)
/*      */                   {
/* 1541 */                     emitPixelStrip(rd, y1, pix);
/*      */                     
/*      */ 
/* 1544 */                     pixelStart++;
/* 1545 */                     width--;
/* 1546 */                     int x1 = pixelStart + 10;
/* 1547 */                     TimeLineView.Strip strip = new TimeLineView.Strip(x1, isContextSwitch ? y1 + 20 - 1 : y1, width, isContextSwitch ? 1 : 20, rd, segment, color);
/*      */                     
/*      */ 
/*      */ 
/* 1551 */                     this.mStripList.add(strip);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           } }
/* 1557 */       for (int ii = 0; ii < TimeLineView.this.mNumRows; ii++) {
/* 1558 */         TimeLineView.Pixel pix = pixels[ii];
/* 1559 */         if (pix.mSegment != null) {
/* 1560 */           TimeLineView.RowData rd = pix.mRowData;
/* 1561 */           int y1 = rd.mRank * 32 + 6;
/*      */           
/* 1563 */           emitPixelStrip(rd, y1, pix);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private static final int yMargin = 1;
/*      */     
/*      */ 
/*      */     private static final int MinZoomPixelMargin = 10;
/*      */     
/*      */ 
/*      */     private double computeWeight(double start, double end, boolean isContextSwitch, int pixel)
/*      */     {
/* 1579 */       if (isContextSwitch) {
/* 1580 */         return 0.0D;
/*      */       }
/* 1582 */       double pixelStartFraction = TimeLineView.this.mScaleInfo.valueToPixelFraction(start);
/* 1583 */       double pixelEndFraction = TimeLineView.this.mScaleInfo.valueToPixelFraction(end);
/* 1584 */       double leftEndPoint = Math.max(pixelStartFraction, pixel - 0.5D);
/* 1585 */       double rightEndPoint = Math.min(pixelEndFraction, pixel + 0.5D);
/* 1586 */       double weight = rightEndPoint - leftEndPoint;
/* 1587 */       return weight;
/*      */     }
/*      */     
/*      */ 
/*      */     private void emitPixelStrip(TimeLineView.RowData rd, int y, TimeLineView.Pixel pixel)
/*      */     {
/* 1593 */       if (pixel.mSegment == null) {
/* 1594 */         return;
/*      */       }
/* 1596 */       int x = pixel.mStart + 10;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1601 */       int height = (int)(pixel.mMaxWeight * 20.0D * 0.75D);
/* 1602 */       if (height < this.mMinStripHeight)
/* 1603 */         height = this.mMinStripHeight;
/* 1604 */       int remainder = 20 - height;
/* 1605 */       if (remainder > 0) {
/* 1606 */         TimeLineView.Strip strip = new TimeLineView.Strip(x, y, 1, remainder, rd, pixel.mSegment, this.mFadeColors ? TimeLineView.this.mColorGray : TimeLineView.this.mColorBlack);
/*      */         
/* 1608 */         this.mStripList.add(strip);
/*      */       }
/*      */       
/*      */ 
/* 1612 */       TimeLineView.Strip strip = new TimeLineView.Strip(x, y + remainder, 1, height, rd, pixel.mSegment, pixel.mColor);
/*      */       
/* 1614 */       this.mStripList.add(strip);
/*      */       
/*      */ 
/* 1617 */       pixel.mSegment = null;
/* 1618 */       pixel.mMaxWeight = 0.0D;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void mouseMove(MouseEvent me)
/*      */     {
/* 1629 */       Point dim = TimeLineView.this.mSurface.getSize();
/* 1630 */       int x = me.x;
/* 1631 */       if (x < 10)
/* 1632 */         x = 10;
/* 1633 */       if (x > dim.x - 60)
/* 1634 */         x = dim.x - 60;
/* 1635 */       this.mMouse.x = x;
/* 1636 */       this.mMouse.y = me.y;
/* 1637 */       TimeLineView.this.mTimescale.setVbarPosition(x);
/* 1638 */       if (this.mGraphicsState == TimeLineView.GraphicsState.Marking) {
/* 1639 */         TimeLineView.this.mTimescale.setMarkEnd(x);
/*      */       }
/*      */       
/* 1642 */       if (this.mGraphicsState == TimeLineView.GraphicsState.Normal)
/*      */       {
/* 1644 */         TimeLineView.this.mSurface.setCursor(this.mNormalCursor);
/* 1645 */       } else if (this.mGraphicsState == TimeLineView.GraphicsState.Marking)
/*      */       {
/* 1647 */         if (this.mMouse.x >= this.mMouseMarkStartX) {
/* 1648 */           TimeLineView.this.mSurface.setCursor(this.mIncreasingCursor);
/*      */         } else
/* 1650 */           TimeLineView.this.mSurface.setCursor(this.mDecreasingCursor);
/*      */       }
/* 1652 */       int rownum = (this.mMouse.y + TimeLineView.this.mScrollOffsetY) / 32;
/* 1653 */       if ((me.y < 0) || (me.y >= dim.y)) {
/* 1654 */         rownum = -1;
/*      */       }
/* 1656 */       if (TimeLineView.this.mMouseRow != rownum) {
/* 1657 */         TimeLineView.this.mMouseRow = rownum;
/* 1658 */         TimeLineView.this.mLabels.redraw();
/*      */       }
/* 1660 */       redraw();
/*      */     }
/*      */     
/*      */     private void mouseDown(MouseEvent me) {
/* 1664 */       Point dim = TimeLineView.this.mSurface.getSize();
/* 1665 */       int x = me.x;
/* 1666 */       if (x < 10)
/* 1667 */         x = 10;
/* 1668 */       if (x > dim.x - 60)
/* 1669 */         x = dim.x - 60;
/* 1670 */       this.mMouseMarkStartX = x;
/* 1671 */       this.mGraphicsState = TimeLineView.GraphicsState.Marking;
/* 1672 */       TimeLineView.this.mSurface.setCursor(this.mIncreasingCursor);
/* 1673 */       TimeLineView.this.mTimescale.setMarkStart(this.mMouseMarkStartX);
/* 1674 */       TimeLineView.this.mTimescale.setMarkEnd(this.mMouseMarkStartX);
/* 1675 */       redraw();
/*      */     }
/*      */     
/*      */     private void mouseUp(MouseEvent me) {
/* 1679 */       TimeLineView.this.mSurface.setCursor(this.mNormalCursor);
/* 1680 */       if (this.mGraphicsState != TimeLineView.GraphicsState.Marking) {
/* 1681 */         this.mGraphicsState = TimeLineView.GraphicsState.Normal;
/* 1682 */         return;
/*      */       }
/* 1684 */       this.mGraphicsState = TimeLineView.GraphicsState.Animating;
/* 1685 */       Point dim = TimeLineView.this.mSurface.getSize();
/*      */       
/*      */ 
/*      */ 
/* 1689 */       if ((me.y <= 0) || (me.y >= dim.y)) {
/* 1690 */         this.mGraphicsState = TimeLineView.GraphicsState.Normal;
/* 1691 */         redraw();
/* 1692 */         return;
/*      */       }
/*      */       
/* 1695 */       int x = me.x;
/* 1696 */       if (x < 10)
/* 1697 */         x = 10;
/* 1698 */       if (x > dim.x - 60)
/* 1699 */         x = dim.x - 60;
/* 1700 */       this.mMouseMarkEndX = x;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1705 */       int dist = this.mMouseMarkEndX - this.mMouseMarkStartX;
/* 1706 */       if (dist < 0)
/* 1707 */         dist = -dist;
/* 1708 */       if (dist <= 2) {
/* 1709 */         this.mGraphicsState = TimeLineView.GraphicsState.Normal;
/*      */         
/*      */ 
/* 1712 */         this.mMouseSelect.x = this.mMouseMarkStartX;
/* 1713 */         this.mMouseSelect.y = me.y;
/* 1714 */         redraw();
/* 1715 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1719 */       if (this.mMouseMarkEndX < this.mMouseMarkStartX) {
/* 1720 */         int temp = this.mMouseMarkEndX;
/* 1721 */         this.mMouseMarkEndX = this.mMouseMarkStartX;
/* 1722 */         this.mMouseMarkStartX = temp;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1727 */       if ((this.mMouseMarkStartX <= 20) && (this.mMouseMarkEndX >= dim.x - 60 - 10))
/*      */       {
/* 1729 */         this.mGraphicsState = TimeLineView.GraphicsState.Normal;
/* 1730 */         redraw();
/* 1731 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1786 */       double minVal = TimeLineView.this.mScaleInfo.getMinVal();
/* 1787 */       double maxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/* 1788 */       double ppr = TimeLineView.this.mScaleInfo.getPixelsPerRange();
/* 1789 */       this.mZoomMin = (minVal + (this.mMouseMarkStartX - 10) / ppr);
/* 1790 */       this.mZoomMax = (minVal + (this.mMouseMarkEndX - 10) / ppr);
/*      */       
/*      */ 
/* 1793 */       if (this.mZoomMin < this.mMinDataVal)
/* 1794 */         this.mZoomMin = this.mMinDataVal;
/* 1795 */       if (this.mZoomMax > this.mMaxDataVal) {
/* 1796 */         this.mZoomMax = this.mMaxDataVal;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1801 */       int xdim = dim.x - 70;
/* 1802 */       TickScaler scaler = new TickScaler(this.mZoomMin, this.mZoomMax, xdim, 50);
/*      */       
/* 1804 */       scaler.computeTicks(false);
/* 1805 */       this.mZoomMin = scaler.getMinVal();
/* 1806 */       this.mZoomMax = scaler.getMaxVal();
/*      */       
/*      */ 
/*      */ 
/* 1810 */       this.mMouseMarkStartX = ((int)((this.mZoomMin - minVal) * ppr + 10.0D));
/* 1811 */       this.mMouseMarkEndX = ((int)((this.mZoomMax - minVal) * ppr + 10.0D));
/* 1812 */       TimeLineView.this.mTimescale.setMarkStart(this.mMouseMarkStartX);
/* 1813 */       TimeLineView.this.mTimescale.setMarkEnd(this.mMouseMarkEndX);
/*      */       
/*      */ 
/* 1816 */       this.mMouseEndDistance = (dim.x - 60 - this.mMouseMarkEndX);
/* 1817 */       this.mMouseStartDistance = (this.mMouseMarkStartX - 10);
/* 1818 */       this.mZoomMouseStart = this.mMouseMarkStartX;
/* 1819 */       this.mZoomMouseEnd = this.mMouseMarkEndX;
/* 1820 */       this.mZoomStep = 0;
/*      */       
/*      */ 
/* 1823 */       this.mMin2ZoomMin = (this.mZoomMin - minVal);
/* 1824 */       this.mZoomMax2Max = (maxVal - this.mZoomMax);
/* 1825 */       this.mZoomFixed = (this.mZoomMin + (this.mZoomMax - this.mZoomMin) * this.mMin2ZoomMin / (this.mMin2ZoomMin + this.mZoomMax2Max));
/*      */       
/* 1827 */       this.mZoomFixedPixel = ((this.mZoomFixed - minVal) * ppr + 10.0D);
/* 1828 */       this.mFixedPixelStartDistance = (this.mZoomFixedPixel - 10.0D);
/* 1829 */       this.mFixedPixelEndDistance = (dim.x - 60 - this.mZoomFixedPixel);
/*      */       
/* 1831 */       this.mZoomMin2Fixed = (this.mZoomFixed - this.mZoomMin);
/* 1832 */       this.mFixed2ZoomMax = (this.mZoomMax - this.mZoomFixed);
/*      */       
/* 1834 */       getDisplay().timerExec(10, this.mZoomAnimator);
/* 1835 */       redraw();
/* 1836 */       update();
/*      */     }
/*      */     
/*      */     private void mouseScrolled(MouseEvent me) {
/* 1840 */       this.mGraphicsState = TimeLineView.GraphicsState.Scrolling;
/* 1841 */       double tMin = TimeLineView.this.mScaleInfo.getMinVal();
/* 1842 */       double tMax = TimeLineView.this.mScaleInfo.getMaxVal();
/* 1843 */       double zoomFactor = 2.0D;
/* 1844 */       double tMinRef = this.mLimitMinVal;
/* 1845 */       double tMaxRef = this.mLimitMaxVal;
/*      */       
/*      */       double tMaxNew;
/*      */       
/* 1849 */       if (me.count > 0)
/*      */       {
/* 1851 */         Point dim = TimeLineView.this.mSurface.getSize();
/* 1852 */         int x = me.x;
/* 1853 */         if (x < 10)
/* 1854 */           x = 10;
/* 1855 */         if (x > dim.x - 60)
/* 1856 */           x = dim.x - 60;
/* 1857 */         double ppr = TimeLineView.this.mScaleInfo.getPixelsPerRange();
/* 1858 */         double t = tMin + (x - 10) / ppr;
/* 1859 */         double tMinNew = Math.max(tMinRef, t - (t - tMin) / zoomFactor);
/* 1860 */         tMaxNew = Math.min(tMaxRef, t + (tMax - t) / zoomFactor);
/*      */       }
/*      */       else {
/* 1863 */         double factor = (tMax - tMin) / (tMaxRef - tMinRef);
/* 1864 */         double tMaxNew; if (factor < 1.0D) {
/* 1865 */           double t = (factor * tMinRef - tMin) / (factor - 1.0D);
/* 1866 */           double tMinNew = Math.max(tMinRef, t - zoomFactor * (t - tMin));
/* 1867 */           tMaxNew = Math.min(tMaxRef, t + zoomFactor * (tMax - t));
/*      */         } else { return; } }
/*      */       double tMaxNew;
/*      */       double tMinNew;
/*      */       double t;
/* 1872 */       TimeLineView.this.mScaleInfo.setMinVal(tMinNew);
/* 1873 */       TimeLineView.this.mScaleInfo.setMaxVal(tMaxNew);
/* 1874 */       TimeLineView.this.mSurface.redraw();
/*      */     }
/*      */     
/*      */ 
/*      */     private void mouseDoubleClick(MouseEvent me) {}
/*      */     
/*      */     public void startScaling(int mouseX)
/*      */     {
/* 1882 */       Point dim = TimeLineView.this.mSurface.getSize();
/* 1883 */       int x = mouseX;
/* 1884 */       if (x < 10)
/* 1885 */         x = 10;
/* 1886 */       if (x > dim.x - 60)
/* 1887 */         x = dim.x - 60;
/* 1888 */       this.mMouseMarkStartX = x;
/* 1889 */       this.mGraphicsState = TimeLineView.GraphicsState.Scaling;
/* 1890 */       this.mScalePixelsPerRange = TimeLineView.this.mScaleInfo.getPixelsPerRange();
/* 1891 */       this.mScaleMinVal = TimeLineView.this.mScaleInfo.getMinVal();
/* 1892 */       this.mScaleMaxVal = TimeLineView.this.mScaleInfo.getMaxVal();
/*      */     }
/*      */     
/*      */     public void stopScaling(int mouseX) {
/* 1896 */       this.mGraphicsState = TimeLineView.GraphicsState.Normal;
/*      */     }
/*      */     
/*      */     private void animateHighlight() {
/* 1900 */       this.mHighlightStep += 1;
/* 1901 */       if (this.mHighlightStep >= this.HIGHLIGHT_STEPS) {
/* 1902 */         this.mFadeColors = false;
/* 1903 */         this.mHighlightStep = 0;
/*      */         
/* 1905 */         this.mCachedEndRow = -1;
/*      */       } else {
/* 1907 */         this.mFadeColors = true;
/* 1908 */         this.mShowHighlightName = true;
/* 1909 */         this.mHighlightHeight = this.highlightHeights[this.mHighlightStep];
/* 1910 */         getDisplay().timerExec(50, this.mHighlightAnimator);
/*      */       }
/* 1912 */       redraw();
/*      */     }
/*      */     
/*      */     private void clearHighlights()
/*      */     {
/* 1917 */       this.mShowHighlightName = false;
/* 1918 */       this.mHighlightHeight = 0;
/* 1919 */       TimeLineView.this.mHighlightMethodData = null;
/* 1920 */       TimeLineView.this.mHighlightCall = null;
/* 1921 */       this.mFadeColors = false;
/* 1922 */       this.mHighlightStep = 0;
/*      */       
/* 1924 */       this.mCachedEndRow = -1;
/* 1925 */       redraw();
/*      */     }
/*      */     
/*      */     private void animateZoom() {
/* 1929 */       this.mZoomStep += 1;
/* 1930 */       if (this.mZoomStep > 8) {
/* 1931 */         this.mGraphicsState = TimeLineView.GraphicsState.Normal;
/*      */         
/* 1933 */         this.mCachedMinVal = (TimeLineView.this.mScaleInfo.getMinVal() + 1.0D);
/* 1934 */       } else if (this.mZoomStep == 8) {
/* 1935 */         TimeLineView.this.mScaleInfo.setMinVal(this.mZoomMin);
/* 1936 */         TimeLineView.this.mScaleInfo.setMaxVal(this.mZoomMax);
/* 1937 */         this.mMouseMarkStartX = 10;
/* 1938 */         Point dim = getSize();
/* 1939 */         this.mMouseMarkEndX = (dim.x - 60);
/* 1940 */         TimeLineView.this.mTimescale.setMarkStart(this.mMouseMarkStartX);
/* 1941 */         TimeLineView.this.mTimescale.setMarkEnd(this.mMouseMarkEndX);
/* 1942 */         getDisplay().timerExec(10, this.mZoomAnimator);
/*      */       }
/*      */       else
/*      */       {
/* 1946 */         double fraction = this.mZoomFractions[this.mZoomStep];
/* 1947 */         this.mMouseMarkStartX = ((int)(this.mZoomMouseStart - fraction * this.mMouseStartDistance));
/* 1948 */         this.mMouseMarkEndX = ((int)(this.mZoomMouseEnd + fraction * this.mMouseEndDistance));
/* 1949 */         TimeLineView.this.mTimescale.setMarkStart(this.mMouseMarkStartX);
/* 1950 */         TimeLineView.this.mTimescale.setMarkEnd(this.mMouseMarkEndX);
/*      */         
/*      */         double ppr;
/*      */         double ppr;
/* 1954 */         if (this.mZoomMin2Fixed >= this.mFixed2ZoomMax) {
/* 1955 */           ppr = (this.mZoomFixedPixel - this.mMouseMarkStartX) / this.mZoomMin2Fixed;
/*      */         } else
/* 1957 */           ppr = (this.mMouseMarkEndX - this.mZoomFixedPixel) / this.mFixed2ZoomMax;
/* 1958 */         double newMin = this.mZoomFixed - this.mFixedPixelStartDistance / ppr;
/* 1959 */         double newMax = this.mZoomFixed + this.mFixedPixelEndDistance / ppr;
/* 1960 */         TimeLineView.this.mScaleInfo.setMinVal(newMin);
/* 1961 */         TimeLineView.this.mScaleInfo.setMaxVal(newMax);
/*      */         
/* 1963 */         getDisplay().timerExec(10, this.mZoomAnimator);
/*      */       }
/* 1965 */       redraw();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1972 */     private TimeLineView.GraphicsState mGraphicsState = TimeLineView.GraphicsState.Normal;
/* 1973 */     private Point mMouse = new Point(10, 0);
/*      */     private int mMouseMarkStartX;
/*      */     private int mMouseMarkEndX;
/* 1976 */     private boolean mDebug = false;
/* 1977 */     private ArrayList<TimeLineView.Strip> mStripList = new ArrayList();
/* 1978 */     private ArrayList<TimeLineView.Range> mHighlightExclusive = new ArrayList();
/* 1979 */     private ArrayList<TimeLineView.Range> mHighlightInclusive = new ArrayList();
/* 1980 */     private int mMinStripHeight = 2;
/*      */     private double mCachedMinVal;
/*      */     private double mCachedMaxVal;
/*      */     private int mCachedStartRow;
/*      */     private int mCachedEndRow;
/*      */     private double mScalePixelsPerRange;
/*      */     private double mScaleMinVal;
/*      */     private double mScaleMaxVal;
/*      */     private double mLimitMinVal;
/*      */     private double mLimitMaxVal;
/*      */     private double mMinDataVal;
/*      */     private double mMaxDataVal;
/*      */     private Cursor mNormalCursor;
/*      */     private Cursor mIncreasingCursor;
/*      */     private Cursor mDecreasingCursor;
/*      */     private static final int ZOOM_TIMER_INTERVAL = 10;
/*      */     private static final int HIGHLIGHT_TIMER_INTERVAL = 50;
/*      */     private static final int ZOOM_STEPS = 8;
/* 1998 */     private int mHighlightHeight = 4;
/* 1999 */     private final int[] highlightHeights = { 0, 2, 4, 5, 6, 5, 4, 2, 4, 5, 6 };
/*      */     
/* 2001 */     private final int HIGHLIGHT_STEPS = this.highlightHeights.length;
/*      */     private boolean mFadeColors;
/*      */     private boolean mShowHighlightName;
/*      */     private double[] mZoomFractions;
/*      */     private int mZoomStep;
/*      */     private int mZoomMouseStart;
/*      */     private int mZoomMouseEnd;
/*      */     private int mMouseStartDistance;
/*      */     private int mMouseEndDistance;
/* 2010 */     private Point mMouseSelect = new Point(0, 0);
/*      */     
/*      */     private double mZoomFixed;
/*      */     private double mZoomFixedPixel;
/*      */     private double mFixedPixelStartDistance;
/*      */     private double mFixedPixelEndDistance;
/*      */     private double mZoomMin2Fixed;
/*      */     private double mMin2ZoomMin;
/*      */     private double mFixed2ZoomMax;
/*      */     private double mZoomMax2Max;
/*      */     private double mZoomMin;
/*      */     private double mZoomMax;
/*      */     private Runnable mZoomAnimator;
/*      */     private Runnable mHighlightAnimator;
/*      */     private int mHighlightStep;
/*      */   }
/*      */   
/*      */   private int computeVisibleRows(int ydim)
/*      */   {
/* 2029 */     int offsetY = this.mScrollOffsetY;
/* 2030 */     int spaceNeeded = this.mNumRows * 32;
/* 2031 */     if (offsetY + ydim > spaceNeeded) {
/* 2032 */       offsetY = spaceNeeded - ydim;
/* 2033 */       if (offsetY < 0) {
/* 2034 */         offsetY = 0;
/*      */       }
/*      */     }
/* 2037 */     this.mStartRow = (offsetY / 32);
/* 2038 */     this.mEndRow = ((offsetY + ydim) / 32);
/* 2039 */     if (this.mEndRow >= this.mNumRows) {
/* 2040 */       this.mEndRow = (this.mNumRows - 1);
/*      */     }
/*      */     
/* 2043 */     return offsetY;
/*      */   }
/*      */   
/*      */   private void startHighlighting()
/*      */   {
/* 2048 */     this.mSurface.mHighlightStep = 0;
/* 2049 */     this.mSurface.mFadeColors = true;
/*      */     
/* 2051 */     this.mSurface.mCachedEndRow = -1;
/* 2052 */     getDisplay().timerExec(0, this.mSurface.mHighlightAnimator); }
/*      */   
/*      */   private static class RowData { private String mName;
/*      */     private int mRank;
/*      */     
/* 2057 */     RowData(TimeLineView.Row row) { this.mName = row.getName();
/* 2058 */       this.mStack = new ArrayList(); }
/*      */     
/*      */     private long mElapsed;
/*      */     
/* 2062 */     public void push(TimeLineView.Block block) { this.mStack.add(block); }
/*      */     
/*      */     private long mEndTime;
/*      */     private ArrayList<TimeLineView.Block> mStack;
/* 2066 */     public TimeLineView.Block top() { if (this.mStack.size() == 0)
/* 2067 */         return null;
/* 2068 */       return (TimeLineView.Block)this.mStack.get(this.mStack.size() - 1);
/*      */     }
/*      */     
/*      */     public void pop() {
/* 2072 */       if (this.mStack.size() == 0)
/* 2073 */         return;
/* 2074 */       this.mStack.remove(this.mStack.size() - 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class Segment {
/*      */     private TimeLineView.RowData mRowData;
/*      */     private TimeLineView.Block mBlock;
/*      */     private long mStartTime;
/*      */     private long mEndTime;
/*      */     private boolean mIsContextSwitch;
/*      */     
/*      */     Segment(TimeLineView.RowData rowData, TimeLineView.Block block, long startTime, long endTime) {
/* 2086 */       this.mRowData = rowData;
/* 2087 */       if (block.isContextSwitch()) {
/* 2088 */         this.mBlock = block.getParentBlock();
/* 2089 */         this.mIsContextSwitch = true;
/*      */       } else {
/* 2091 */         this.mBlock = block;
/*      */       }
/* 2093 */       this.mStartTime = startTime;
/* 2094 */       this.mEndTime = endTime;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class Strip {
/*      */     int mX;
/*      */     int mY;
/*      */     int mWidth;
/*      */     int mHeight;
/*      */     TimeLineView.RowData mRowData;
/*      */     TimeLineView.Segment mSegment;
/*      */     Color mColor;
/*      */     
/* 2107 */     Strip(int x, int y, int width, int height, TimeLineView.RowData rowData, TimeLineView.Segment segment, Color color) { this.mX = x;
/* 2108 */       this.mY = y;
/* 2109 */       this.mWidth = width;
/* 2110 */       this.mHeight = height;
/* 2111 */       this.mRowData = rowData;
/* 2112 */       this.mSegment = segment;
/* 2113 */       this.mColor = color;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class Pixel
/*      */   {
/*      */     public void setFields(int start, double weight, TimeLineView.Segment segment, Color color, TimeLineView.RowData rowData)
/*      */     {
/* 2128 */       this.mStart = start;
/* 2129 */       this.mMaxWeight = weight;
/* 2130 */       this.mSegment = segment;
/* 2131 */       this.mColor = color;
/* 2132 */       this.mRowData = rowData;
/*      */     }
/*      */     
/* 2135 */     int mStart = -2;
/*      */     double mMaxWeight;
/*      */     TimeLineView.Segment mSegment;
/*      */     Color mColor;
/*      */     TimeLineView.RowData mRowData;
/*      */   }
/*      */   
/*      */   private static class Range {
/*      */     Range(int xStart, int width, int y, Color color) {
/* 2144 */       this.mXdim.x = xStart;
/* 2145 */       this.mXdim.y = width;
/* 2146 */       this.mY = y;
/* 2147 */       this.mColor = color;
/*      */     }
/*      */     
/* 2150 */     Point mXdim = new Point(0, 0);
/*      */     int mY;
/*      */     Color mColor;
/*      */   }
/*      */ }


/* Location:              /Users/frank/Applications/android-sdk-macosx/tools/lib/traceview.jar!/com/android/traceview/TimeLineView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */